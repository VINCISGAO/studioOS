import { Badge } from "@/components/ui/badge";
import type { Locale } from "@/lib/i18n";
import type { ProjectStatus } from "@/lib/types";

const labels: Record<Locale, Record<ProjectStatus, string>> = {
  en: {
    submitted: "Submitted",
    approved: "Approved",
    waiting_payment: "Waiting payment",
    paid: "Paid",
    matching: "Matching",
    assigned: "Assigned",
    matched: "Matched",
    in_production: "In production",
    review: "Review",
    revision: "Revision",
    delivered: "Delivered",
    completed: "Completed",
    cancelled: "Cancelled",
    disputed: "Disputed",
    refunded: "Refunded"
  },
  zh: {
    submitted: "已提交",
    approved: "已审核",
    waiting_payment: "待付款",
    paid: "已付款",
    matching: "匹配中",
    assigned: "已分配",
    matched: "已匹配",
    in_production: "制作中",
    review: "待审核",
    revision: "修改中",
    delivered: "已交付",
    completed: "已完成",
    cancelled: "已取消",
    disputed: "争议中",
    refunded: "已退款"
  }
};

export function StatusBadge({ status, locale = "en" }: { status: ProjectStatus; locale?: Locale }) {
  const variant = ["delivered", "completed", "paid", "approved", "assigned", "matched"].includes(status)
    ? "success"
    : ["review", "revision", "matching", "waiting_payment", "in_production", "disputed"].includes(status)
      ? "warning"
      : "secondary";

  return <Badge variant={variant}>{labels[locale][status]}</Badge>;
}
