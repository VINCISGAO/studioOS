import Link from "next/link";
import { ArrowRight, Film, Menu } from "lucide-react";
import { LanguageSwitcher } from "@/components/language-switcher";
import { Button } from "@/components/ui/button";
import type { Locale } from "@/lib/i18n";
import { withLocale } from "@/lib/i18n";

const navText = {
  en: {
    creators: "Creators",
    projects: "Briefs",
    pricing: "Pricing",
    creator: "Creator",
    signIn: "Sign in",
    dashboard: "Dashboard",
    admin: "Admin",
    start: "Start"
  },
  zh: {
    creators: "作品库",
    projects: "需求",
    pricing: "价格",
    creator: "承接人",
    signIn: "登录",
    dashboard: "客户后台",
    admin: "管理后台",
    start: "开始"
  }
};

export function SiteHeader({ locale }: { locale: Locale }) {
  const t = navText[locale];

  return (
    <header className="sticky top-0 z-40 border-b bg-background/85 backdrop-blur">
      <div className="mx-auto flex h-16 max-w-7xl items-center justify-between px-4 sm:px-6 lg:px-8">
        <Link href={withLocale("/", locale)} className="flex items-center gap-2 text-sm font-semibold">
          <span className="flex h-8 w-8 items-center justify-center rounded-md bg-primary text-primary-foreground shadow-sm">
            <Film className="h-4 w-4" />
          </span>
          <span className="text-base">AdBridge</span>
        </Link>
        <nav className="hidden items-center gap-1 rounded-md border bg-white/70 p-1 text-sm text-muted-foreground shadow-sm backdrop-blur md:flex">
          <Link href={withLocale("/creators", locale)} className="hover:text-foreground">
            <span className="block rounded px-3 py-1.5 hover:bg-white">{t.creators}</span>
          </Link>
          <Link href={withLocale("/projects", locale)} className="hover:text-foreground">
            <span className="block rounded px-3 py-1.5 hover:bg-white">{t.projects}</span>
          </Link>
          <Link href={withLocale("/pricing", locale)} className="hover:text-foreground">
            <span className="block rounded px-3 py-1.5 hover:bg-white">{t.pricing}</span>
          </Link>
          <Link href={withLocale("/creator", locale)} className="hover:text-foreground">
            <span className="block rounded px-3 py-1.5 hover:bg-white">{t.creator}</span>
          </Link>
          <Link href={withLocale("/login", locale)} className="hover:text-foreground">
            <span className="block rounded px-3 py-1.5 hover:bg-white">{t.signIn}</span>
          </Link>
          <Link href={withLocale("/dashboard", locale)} className="hover:text-foreground">
            <span className="block rounded px-3 py-1.5 hover:bg-white">{t.dashboard}</span>
          </Link>
          <Link href={withLocale("/admin", locale)} className="hover:text-foreground">
            <span className="block rounded px-3 py-1.5 hover:bg-white">{t.admin}</span>
          </Link>
        </nav>
        <div className="flex items-center gap-2">
          <LanguageSwitcher locale={locale} />
          <Button asChild size="sm">
            <Link href={withLocale("/start", locale)}>
              {t.start} <ArrowRight className="h-4 w-4" />
            </Link>
          </Button>
          <Button size="icon" variant="outline" className="md:hidden" aria-label="Menu">
            <Menu className="h-4 w-4" />
          </Button>
        </div>
      </div>
    </header>
  );
}
