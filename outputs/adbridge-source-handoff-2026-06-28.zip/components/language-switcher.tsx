"use client";

import Link from "next/link";
import { usePathname, useSearchParams } from "next/navigation";
import { Globe2 } from "lucide-react";
import { cn } from "@/lib/utils";
import type { Locale } from "@/lib/i18n";

export function LanguageSwitcher({ locale }: { locale: Locale }) {
  const pathname = usePathname();
  const searchParams = useSearchParams();

  function hrefFor(nextLocale: Locale) {
    const params = new URLSearchParams(searchParams.toString());
    params.set("lang", nextLocale);
    return `${pathname}?${params.toString()}`;
  }

  return (
    <div className="flex h-9 items-center gap-1 rounded-md border bg-white/80 p-1 text-xs font-medium shadow-sm backdrop-blur">
      <Globe2 className="ml-1 h-3.5 w-3.5 text-muted-foreground" />
      {(["en", "zh"] as const).map((item) => (
        <Link
          key={item}
          href={hrefFor(item)}
          className={cn(
            "rounded px-2.5 py-1.5 transition-colors",
            locale === item
              ? "bg-primary text-primary-foreground shadow-sm"
              : "text-muted-foreground hover:text-foreground"
          )}
        >
          {item === "en" ? "EN" : "中文"}
        </Link>
      ))}
    </div>
  );
}
