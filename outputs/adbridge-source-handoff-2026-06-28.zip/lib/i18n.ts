export const locales = ["en", "zh"] as const;

export type Locale = (typeof locales)[number];

export type SearchParams = Record<string, string | string[] | undefined>;

export function getLocale(searchParams?: SearchParams): Locale {
  const raw = searchParams?.lang;
  const lang = Array.isArray(raw) ? raw[0] : raw;
  return lang === "zh" ? "zh" : "en";
}

export function withLocale(path: string, locale: Locale) {
  const separator = path.includes("?") ? "&" : "?";
  return `${path}${separator}lang=${locale}`;
}

export function isZh(locale: Locale) {
  return locale === "zh";
}
