import Link from "next/link";
import {
  ArrowLeft,
  BadgeCheck,
  Eye,
  Film,
  Github,
  Globe2,
  Mail,
  Phone,
  QrCode,
  ScanLine,
  ShieldCheck
} from "lucide-react";
import { oauthSignInAction, signInAction, signUpAction } from "@/app/actions";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { getLocale, type Locale, type SearchParams, withLocale } from "@/lib/i18n";

type LoginPageProps = {
  searchParams: Promise<SearchParams & { error?: string; site?: string; mode?: string }>;
};

const copy = {
  en: {
    domestic: "China site",
    global: "Global site",
    google: "Continue with Google",
    github: "Continue with GitHub",
    divider: "or continue with",
    email: "Email",
    emailPlaceholder: "Enter your email",
    password: "Password",
    passwordPlaceholder: "Enter password",
    forgot: "Forgot password?",
    login: "Sign in",
    registerPrompt: "No account?",
    register: "Create account",
    existingPrompt: "Already have an account?",
    terms: "By signing in, you agree to the",
    service: "Terms",
    privacy: "Privacy Policy",
    and: "and",
    phone: "Phone",
    wechat: "WeChat",
    phoneLabel: "Phone number",
    phonePlaceholder: "Enter phone number",
    codeLabel: "Verification code",
    codePlaceholder: "Enter verification code",
    getCode: "Get code",
    invite: "Invite code (optional)",
    invitePlaceholder: "Invite code can unlock extra credits",
    phoneSubmit: "Sign in / Register",
    phoneNote: "Unregistered phone numbers will create an account automatically",
    scan: "Scan with WeChat to sign in",
    refreshQr: "Refresh QR code",
    configError: "Add Supabase environment keys to enable authentication.",
    unsupported: "This login provider is not configured yet.",
    back: "Back",
    brandEyebrow: "AdBridge Client Access",
    brandTitle: "A private production desk for global AI advertising.",
    brandBody:
      "Track orders, review cuts, and download final deliverables through a managed production workflow built for international brand teams.",
    benefits: ["One managed client desk", "Vetted global studios", "Commercial-ready deliverables"]
  },
  zh: {
    domestic: "国内站",
    global: "国际站",
    google: "使用 Google 登录",
    github: "使用 GitHub 登录",
    divider: "或使用以下方式继续",
    email: "邮箱",
    emailPlaceholder: "请输入您的邮箱",
    password: "密码",
    passwordPlaceholder: "请输入密码",
    forgot: "忘记密码？",
    login: "登录",
    registerPrompt: "还没有账户？",
    register: "注册",
    existingPrompt: "已有账户？",
    terms: "登录即表示同意",
    service: "服务条款",
    privacy: "隐私政策",
    and: "和",
    phone: "手机",
    wechat: "微信",
    phoneLabel: "手机号",
    phonePlaceholder: "请输入手机号",
    codeLabel: "验证码",
    codePlaceholder: "请输入验证码",
    getCode: "获取验证码",
    invite: "邀请码（选填）",
    invitePlaceholder: "输入邀请码可获得额外积分",
    phoneSubmit: "登录 / 注册",
    phoneNote: "未注册的手机号将自动创建账号",
    scan: "请使用微信扫描二维码登录",
    refreshQr: "刷新二维码",
    configError: "请添加 Supabase 环境密钥以启用身份验证。",
    unsupported: "该登录方式尚未配置。",
    back: "返回",
    brandEyebrow: "AdBridge 客户访问",
    brandTitle: "连接美国营销团队与全球 AI 创意执行者。",
    brandBody: "通过一个统一的客户工作台跟踪订单、审核视频并下载最终交付文件，让跨国广告制作保持清晰、可控和高质感。",
    benefits: ["统一客户对接窗口", "全球严选制作团队", "可投放商业交付文件"]
  }
};

export default async function LoginPage({ searchParams }: LoginPageProps) {
  const params = await searchParams;
  const locale = getLocale(params);
  const t = copy[locale];
  const site = params.site === "cn" ? "cn" : "global";
  const mode = params.mode === "wechat" ? "wechat" : "phone";
  const authMode = params.auth === "register" ? "register" : "login";
  const error =
    params.error === "auth-config"
      ? t.configError
      : params.error === "unsupported-provider"
        ? t.unsupported
        : params.error;

  return (
    <main className="min-h-screen bg-[#f7f7f4] px-4 py-5 text-[#191919] sm:px-6 lg:px-8">
      <div className="mx-auto flex min-h-[calc(100vh-2.5rem)] max-w-6xl flex-col">
        <div className="flex h-12 items-center justify-between">
          <Link href={withLocale("/", locale)} className="flex items-center gap-2 text-sm font-semibold">
            <span className="flex h-8 w-8 items-center justify-center rounded-md bg-black text-white">
              <Film className="h-4 w-4" />
            </span>
            AdBridge
          </Link>
          <Button asChild variant="outline" size="sm" className="bg-white/80">
            <Link href={withLocale("/", locale)}>
              <ArrowLeft className="h-4 w-4" /> {t.back}
            </Link>
          </Button>
        </div>

        <section className="flex flex-1 items-center justify-center py-8">
          <div className="mx-auto grid w-full gap-8 lg:grid-cols-[0.9fr_0.82fr] lg:items-center">
            <div className="hidden max-w-xl lg:block">
              <div className="inline-flex items-center gap-2 rounded-md border bg-white px-3 py-1.5 text-sm text-muted-foreground shadow-sm">
                <Globe2 className="h-4 w-4 text-foreground" />
                {t.brandEyebrow}
              </div>
              <h1 className="mt-7 text-balance text-5xl font-semibold leading-[1.05]">
                {t.brandTitle}
              </h1>
              <p className="mt-5 max-w-2xl text-lg leading-8 text-muted-foreground">{t.brandBody}</p>
              <div className="mt-8 grid max-w-xl gap-2.5">
                {t.benefits.map((item) => (
                  <div
                    key={item}
                    className="flex items-center gap-3 border-t border-[#deded9] py-3 text-sm font-medium text-muted-foreground"
                  >
                    <BadgeCheck className="h-4 w-4 text-foreground" />
                    {item}
                  </div>
                ))}
              </div>
            </div>

            <div className="mx-auto w-full max-w-[480px]">
            <div className="rounded-lg border border-[#deded9] bg-white p-5 shadow-luxe sm:p-7">
              <div className="mb-7 flex items-start justify-between gap-4">
                <div>
                  <div className="inline-flex items-center gap-2 rounded-md bg-muted px-2.5 py-1 text-xs font-medium text-muted-foreground">
                    <ShieldCheck className="h-3.5 w-3.5" />
                    {t.brandEyebrow}
                  </div>
                  <h2 className="mt-4 text-3xl font-semibold leading-tight">
                    {site === "global" ? t.global : t.domestic}
                  </h2>
                </div>
                <div className="flex w-fit rounded-md border bg-muted p-1">
                  <Segment href={`/login?lang=${locale}&site=cn&mode=phone`} active={site === "cn"}>
                    {site === "cn" ? <span className="h-2 w-2 rounded-full bg-emerald-500" /> : null}
                    {t.domestic}
                  </Segment>
                  <Segment href={`/login?lang=${locale}&site=global`} active={site === "global"}>
                    {site === "global" ? <span className="h-2 w-2 rounded-full bg-emerald-500" /> : null}
                    {t.global}
                  </Segment>
                </div>
              </div>

              {site === "global" ? (
                <GlobalLogin locale={locale} t={t} error={error} authMode={authMode} />
              ) : (
                <DomesticLogin locale={locale} t={t} mode={mode} error={error} />
              )}
            </div>
          </div>
          </div>
        </section>
      </div>
    </main>
  );
}

function GlobalLogin({
  locale,
  t,
  error,
  authMode
}: {
  locale: Locale;
  t: (typeof copy)[Locale];
  error?: string;
  authMode: "login" | "register";
}) {
  const isRegister = authMode === "register";

  return (
    <div>
      <div className="grid gap-3">
        <OAuthButton provider="google" label={t.google} locale={locale} />
        <OAuthButton provider="github" label={t.github} locale={locale} />
      </div>

      <div className="my-6 flex items-center gap-4 text-center text-sm text-muted-foreground">
        <div className="h-px flex-1 bg-border" />
        <span>{t.divider}</span>
        <div className="h-px flex-1 bg-border" />
      </div>

      <form action={isRegister ? signUpAction : signInAction} className="grid gap-4">
        <input type="hidden" name="lang" value={locale} />
        <Field
          label={t.email}
          name="email"
          type="email"
          placeholder={t.emailPlaceholder}
          icon={<Mail className="h-5 w-5 text-muted-foreground" />}
        />
        <div className="grid gap-3">
          <div className="flex items-center justify-between">
            <Label htmlFor="password" className="text-sm font-semibold text-muted-foreground">
              {t.password}
            </Label>
            <Link href="#" className="text-sm text-muted-foreground hover:text-foreground">
              {t.forgot}
            </Link>
          </div>
          <div className="relative">
            <Input
              id="password"
              name="password"
              type="password"
              required
              minLength={8}
              placeholder={t.passwordPlaceholder}
              className="h-12 rounded-xl border-[#dfdfdc] bg-white px-4 pr-12 text-base shadow-sm placeholder:text-[#8c8f96]"
            />
            <Eye className="absolute right-4 top-1/2 h-5 w-5 -translate-y-1/2 text-muted-foreground" />
          </div>
        </div>

        {error ? <ErrorMessage message={error} /> : null}

        <Button className="mt-4 h-12 rounded-xl bg-[#c9822f] text-base font-semibold text-white shadow-sm hover:bg-[#b8742b]">
          {isRegister ? t.register : t.login}
        </Button>
      </form>

      <div className="mt-5 text-center text-sm text-muted-foreground">
        {isRegister ? t.existingPrompt : t.registerPrompt}{" "}
        <Link
          href={`/login?lang=${locale}&site=global&auth=${isRegister ? "login" : "register"}`}
          className="font-semibold text-foreground"
        >
          {isRegister ? t.login : t.register}
        </Link>
      </div>
      <PolicyText t={t} />
    </div>
  );
}

function DomesticLogin({
  locale,
  t,
  mode,
  error
}: {
  locale: Locale;
  t: (typeof copy)[Locale];
  mode: string;
  error?: string;
}) {
  return (
    <div>
      <div className="flex border-b">
        <LoginTab href={`/login?lang=${locale}&site=cn&mode=phone`} active={mode !== "wechat"}>
          <Phone className="h-6 w-6" />
          {t.phone}
        </LoginTab>
        <LoginTab href={`/login?lang=${locale}&site=cn&mode=wechat`} active={mode === "wechat"}>
          <ScanLine className="h-6 w-6" />
          {t.wechat}
        </LoginTab>
      </div>

      {mode === "wechat" ? (
        <div className="py-9">
          <div className="mx-auto flex h-56 w-56 items-center justify-center rounded-2xl border bg-white shadow-sm">
            <QrCode className="h-44 w-44 text-black" strokeWidth={1.8} />
          </div>
          <p className="mt-5 text-center text-sm text-muted-foreground">{t.scan}</p>
          <p className="mt-2 text-center text-sm text-muted-foreground">{t.refreshQr}</p>
          <div className="mt-7">
            <Field label={t.invite} name="invite" placeholder={t.invitePlaceholder} />
          </div>
          {error ? <ErrorMessage message={error} /> : null}
        </div>
      ) : (
        <form className="grid gap-5 py-8">
          <Field label={t.phoneLabel} name="phone" type="tel" placeholder={t.phonePlaceholder} />
          <div className="grid gap-3">
            <Label htmlFor="code" className="text-sm font-semibold text-muted-foreground">
              {t.codeLabel}
            </Label>
            <div className="relative">
              <Input
                id="code"
                name="code"
                placeholder={t.codePlaceholder}
                className="h-12 rounded-xl border-[#dfdfdc] bg-white px-4 pr-32 text-base shadow-sm placeholder:text-[#9aa0aa]"
              />
              <button
                type="button"
                className="absolute right-4 top-1/2 -translate-y-1/2 border-l pl-4 text-sm font-semibold text-muted-foreground"
              >
                {t.getCode}
              </button>
            </div>
          </div>
          <Field label={t.invite} name="invite" placeholder={t.invitePlaceholder} />
          {error ? <ErrorMessage message={error} /> : null}
          <Button
            type="button"
            className="mt-4 h-12 rounded-xl bg-[#9e9e9a] text-base font-semibold text-white shadow-sm hover:bg-[#8f8f8b]"
          >
            {t.phoneSubmit}
          </Button>
          <p className="text-center text-sm text-muted-foreground">{t.phoneNote}</p>
        </form>
      )}

      <PolicyText t={t} />
    </div>
  );
}

function Segment({
  href,
  active,
  children
}: {
  href: string;
  active: boolean;
  children: React.ReactNode;
}) {
  return (
    <Link
      href={href}
      className={`flex items-center justify-center gap-2 rounded px-3 py-1.5 text-sm font-semibold transition ${
        active ? "bg-white text-foreground shadow-sm" : "text-muted-foreground"
      }`}
    >
      {children}
    </Link>
  );
}

function LoginTab({
  href,
  active,
  children
}: {
  href: string;
  active: boolean;
  children: React.ReactNode;
}) {
  return (
    <Link
      href={href}
      className={`flex items-center gap-2 px-3 py-4 text-base font-semibold ${
        active ? "border-b-2 border-foreground text-foreground" : "text-muted-foreground"
      }`}
    >
      {children}
    </Link>
  );
}

function OAuthButton({
  provider,
  label,
  locale
}: {
  provider: "google" | "github";
  label: string;
  locale: Locale;
}) {
  return (
    <form action={oauthSignInAction}>
      <input type="hidden" name="lang" value={locale} />
      <input type="hidden" name="provider" value={provider} />
      <Button
        variant="outline"
        className="h-12 w-full rounded-xl border-[#dfdfdc] bg-white text-base font-semibold shadow-sm hover:bg-white"
      >
        {provider === "google" ? (
          <span className="text-xl font-bold">
            <span className="text-[#4285f4]">G</span>
          </span>
        ) : (
          <Github className="h-5 w-5" />
        )}
        {label}
      </Button>
    </form>
  );
}

function Field({
  label,
  name,
  type = "text",
  placeholder,
  icon
}: {
  label: string;
  name: string;
  type?: string;
  placeholder?: string;
  icon?: React.ReactNode;
}) {
  return (
    <div className="grid gap-2">
      <Label htmlFor={name} className="text-sm font-semibold text-muted-foreground">
        {label}
      </Label>
      <div className="relative">
        <Input
          id={name}
          name={name}
          type={type}
          required={name === "email"}
          placeholder={placeholder}
          className="h-12 rounded-xl border-[#dfdfdc] bg-white px-4 text-base shadow-sm placeholder:text-[#9aa0aa]"
        />
        {icon ? <div className="absolute right-4 top-1/2 -translate-y-1/2">{icon}</div> : null}
      </div>
    </div>
  );
}

function ErrorMessage({ message }: { message: string }) {
  return (
    <div className="rounded-xl border border-destructive/30 bg-destructive/5 p-3 text-center text-sm text-destructive">
      {message}
    </div>
  );
}

function PolicyText({ t }: { t: (typeof copy)[Locale] }) {
  return (
    <p className="mt-6 text-center text-xs leading-6 text-muted-foreground">
      {t.terms}{" "}
      <Link href="#" className="font-semibold text-foreground underline underline-offset-4">
        {t.service}
      </Link>{" "}
      {t.and}{" "}
      <Link href="#" className="font-semibold text-foreground underline underline-offset-4">
        {t.privacy}
      </Link>
    </p>
  );
}
