import Image from "next/image";
import Link from "next/link";
import { ArrowRight, Clock3, FileText, Play, Search, ShieldCheck, Sparkles } from "lucide-react";
import { PageShell } from "@/components/page-shell";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Card, CardContent } from "@/components/ui/card";
import { creatorWorks, creators } from "@/lib/data";
import { getLocale, type SearchParams, withLocale } from "@/lib/i18n";

const copy = {
  en: {
    eyebrow: "Creator portfolio marketplace",
    title: "Browse AI ad creators by real work, then request a quote.",
    subtitle:
      "Creators publish portfolio pieces first. Brands compare style, category, platform fit, price range, and turnaround before opening an inquiry.",
    search: "Search works, styles, categories",
    inquire: "Request quote",
    view: "View profile",
    quote: "Quote",
    customQuote: "Custom quote",
    turnaround: "Turnaround",
    trust: ["Creator portfolios first", "Quote before escrow", "Deposit-backed production"]
  },
  zh: {
    eyebrow: "AI 创作者作品库",
    title: "先看作品，再向合适的 AI 创作者询价。",
    subtitle:
      "创作者先注册账号并发布作品。广告需求方根据风格、品类、平台、价格和交付周期筛选，再发起询价，平台负责担保交易和争议处理。",
    search: "搜索作品、风格、品类",
    inquire: "发起询价",
    view: "查看主页",
    quote: "报价",
    customQuote: "按项目询价",
    turnaround: "交付周期",
    trust: ["创作者先展示作品", "询价后再托管付款", "保证金约束交付"]
  }
};

type CreatorsPageProps = {
  searchParams: Promise<SearchParams>;
};

export default async function CreatorsPage({ searchParams }: CreatorsPageProps) {
  const locale = getLocale(await searchParams);
  const t = copy[locale];
  const activeCreators = creators.filter((creator) => ["active", "approved"].includes(creator.status));

  return (
    <PageShell locale={locale}>
      <main className="bg-[#f6f6f3]">
        <section className="border-b">
          <div className="mx-auto grid max-w-7xl gap-10 px-4 py-16 sm:px-6 lg:grid-cols-[0.74fr_0.26fr] lg:px-8">
            <div>
              <div className="inline-flex items-center gap-2 rounded-md border bg-white px-3 py-1.5 text-sm text-muted-foreground shadow-sm">
                <Sparkles className="h-4 w-4 text-foreground" />
                {t.eyebrow}
              </div>
              <h1 className="mt-6 max-w-4xl text-balance text-5xl font-semibold leading-tight sm:text-6xl">
                {t.title}
              </h1>
              <p className="mt-6 max-w-3xl text-lg leading-8 text-muted-foreground">{t.subtitle}</p>
              <div className="mt-8 flex max-w-2xl items-center gap-3 rounded-lg border bg-white px-4 py-3 text-muted-foreground shadow-sm">
                <Search className="h-5 w-5" />
                <span>{t.search}</span>
              </div>
            </div>
            <Card className="bg-white shadow-luxe">
              <CardContent className="p-6">
                <ShieldCheck className="h-6 w-6" />
                <div className="mt-5 grid gap-3">
                  {t.trust.map((item) => (
                    <div key={item} className="border-t pt-3 text-sm font-medium text-muted-foreground">
                      {item}
                    </div>
                  ))}
                </div>
              </CardContent>
            </Card>
          </div>
        </section>

        <section className="mx-auto max-w-7xl px-4 py-10 sm:px-6 lg:px-8">
          <div className="grid gap-5 lg:grid-cols-4">
            {creatorWorks.map((work) => {
              const creator = creators.find((item) => item.id === work.creator_id);

              return (
                <Card key={work.id} className="overflow-hidden bg-white shadow-none">
                  <div className="relative aspect-[4/3] bg-muted">
                    <Image src={work.thumbnail_url} alt={work.title} fill className="object-cover" />
                    <div className="absolute left-3 top-3 rounded-md bg-black/80 px-2 py-1 text-xs font-medium text-white">
                      {work.platform}
                    </div>
                    <div className="absolute bottom-3 right-3 flex h-9 w-9 items-center justify-center rounded-full bg-white/90 text-foreground shadow-sm">
                      <Play className="h-4 w-4 fill-current" />
                    </div>
                  </div>
                  <CardContent className="flex h-[330px] flex-col p-5">
                    <div className="flex items-start justify-between gap-3">
                      <div>
                        <p className="text-xs font-medium uppercase text-muted-foreground">{work.category}</p>
                        <h2 className="mt-2 text-xl font-semibold leading-tight">{work.title}</h2>
                      </div>
                      <Badge variant="secondary">{work.format}</Badge>
                    </div>
                    <p className="mt-3 line-clamp-3 text-sm leading-6 text-muted-foreground">{work.description}</p>
                    <div className="mt-4 grid gap-2 text-sm">
                      <Meta icon={FileText} label={t.quote} value={t.customQuote} />
                      <Meta icon={Clock3} label={t.turnaround} value={work.turnaround} />
                    </div>
                    <div className="mt-4 flex flex-wrap gap-2">
                      {work.tags.slice(0, 3).map((tag) => (
                        <Badge key={tag} variant="outline">{tag}</Badge>
                      ))}
                    </div>
                    <div className="mt-auto grid grid-cols-2 gap-2 pt-5">
                      <Button asChild variant="outline">
                        <Link href={withLocale(`/creators/${creator?.id}`, locale)}>{t.view}</Link>
                      </Button>
                      <Button asChild>
                        <Link href={withLocale(`/creators/${creator?.id}?work=${work.id}#inquiry`, locale)}>
                          {t.inquire}
                        </Link>
                      </Button>
                    </div>
                  </CardContent>
                </Card>
              );
            })}
          </div>

          <div className="mt-12 grid gap-5 md:grid-cols-3">
            {activeCreators.map((creator) => (
              <Card key={creator.id} className="bg-white shadow-none">
                <CardContent className="p-6">
                  <div className="flex items-start justify-between gap-3">
                    <div>
                      <h2 className="text-xl font-semibold">{creator.name}</h2>
                      <p className="mt-1 text-sm text-muted-foreground">{creator.country}</p>
                    </div>
                    <Badge variant="success">{creator.rating}</Badge>
                  </div>
                  <p className="mt-4 text-sm leading-6 text-muted-foreground">{creator.headline}</p>
                  <Button asChild className="mt-5 w-full" variant="outline">
                    <Link href={withLocale(`/creators/${creator.id}`, locale)}>
                      {t.view} <ArrowRight className="h-4 w-4" />
                    </Link>
                  </Button>
                </CardContent>
              </Card>
            ))}
          </div>
        </section>
      </main>
    </PageShell>
  );
}

function Meta({ icon: Icon, label, value }: { icon: typeof FileText; label: string; value: string }) {
  return (
    <div className="flex items-center justify-between gap-3 rounded-md border bg-muted/30 px-3 py-2">
      <span className="flex items-center gap-2 text-muted-foreground">
        <Icon className="h-4 w-4" />
        {label}
      </span>
      <span className="font-medium">{value}</span>
    </div>
  );
}
