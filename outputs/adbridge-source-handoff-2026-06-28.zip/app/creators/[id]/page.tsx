import Image from "next/image";
import Link from "next/link";
import { ArrowLeft, Clock3, FileText, Mail, ShieldCheck, Star } from "lucide-react";
import { PageShell } from "@/components/page-shell";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Card, CardContent } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { creatorWorks, creators } from "@/lib/data";
import { getLocale, type SearchParams, withLocale } from "@/lib/i18n";

const copy = {
  en: {
    back: "Back to creators",
    profile: "Creator profile",
    works: "Portfolio works",
    inquiry: "Request a quote",
    inquiryBody:
      "Send a focused inquiry to this creator. AdBridge can convert the accepted quote into an escrow-backed order.",
    fields: {
      name: "Your name",
      email: "Email",
      company: "Company",
      budget: "Budget range",
      message: "Project message"
    },
    submit: "Send inquiry",
    quote: "Quote",
    customQuote: "Custom quote",
    turnaround: "Turnaround",
    deposit: "Deposit",
    notFound: "Creator not found"
  },
  zh: {
    back: "返回作品库",
    profile: "创作者主页",
    works: "作品展示",
    inquiry: "发起询价",
    inquiryBody: "向这位创作者发送明确询价。报价确认后，AdBridge 可以把询价转成平台托管订单。",
    fields: {
      name: "你的姓名",
      email: "邮箱",
      company: "公司",
      budget: "预算范围",
      message: "项目需求"
    },
    submit: "发送询价",
    quote: "报价",
    customQuote: "按项目询价",
    turnaround: "交付周期",
    deposit: "保证金",
    notFound: "未找到创作者"
  }
};

type CreatorProfilePageProps = {
  params: Promise<{ id: string }>;
  searchParams: Promise<SearchParams & { work?: string }>;
};

export default async function CreatorProfilePage({ params, searchParams }: CreatorProfilePageProps) {
  const [{ id }, query] = await Promise.all([params, searchParams]);
  const locale = getLocale(query);
  const t = copy[locale];
  const creator = creators.find((item) => item.id === id);

  if (!creator) {
    return (
      <PageShell locale={locale}>
        <main className="mx-auto max-w-3xl px-4 py-16 text-center">
          <h1 className="text-3xl font-semibold">{t.notFound}</h1>
          <Button asChild className="mt-6">
            <Link href={withLocale("/creators", locale)}>{t.back}</Link>
          </Button>
        </main>
      </PageShell>
    );
  }

  const works = creatorWorks.filter((work) => work.creator_id === creator.id);
  const selectedWork = works.find((work) => work.id === query.work) ?? works[0];

  return (
    <PageShell locale={locale}>
      <main className="bg-[#f6f6f3]">
        <section className="mx-auto max-w-7xl px-4 py-10 sm:px-6 lg:px-8">
          <Button asChild variant="outline" size="sm">
            <Link href={withLocale("/creators", locale)}>
              <ArrowLeft className="h-4 w-4" /> {t.back}
            </Link>
          </Button>

          <div className="mt-8 grid gap-8 lg:grid-cols-[0.64fr_0.36fr]">
            <div>
              <p className="text-sm font-semibold uppercase tracking-[0.2em] text-muted-foreground">{t.profile}</p>
              <h1 className="mt-3 text-5xl font-semibold tracking-tight">{creator.name}</h1>
              <p className="mt-4 max-w-3xl text-xl leading-8 text-muted-foreground">{creator.headline}</p>
              <p className="mt-5 max-w-3xl text-base leading-7 text-muted-foreground">{creator.bio}</p>
              <div className="mt-6 flex flex-wrap gap-2">
                <Badge variant="success">
                  <Star className="mr-1 h-3.5 w-3.5 fill-current" />
                  {creator.rating}
                </Badge>
                <Badge variant="secondary">{creator.country}</Badge>
                <Badge variant="secondary">{creator.delivery_speed}</Badge>
                <Badge variant={creator.deposit_status === "paid" ? "success" : "warning"}>
                  <ShieldCheck className="mr-1 h-3.5 w-3.5" />
                  {t.deposit}: {creator.deposit_status}
                </Badge>
              </div>
            </div>

            <Card id="inquiry" className="bg-white shadow-luxe">
              <CardContent className="p-6">
                <h2 className="text-xl font-semibold">{t.inquiry}</h2>
                <p className="mt-2 text-sm leading-6 text-muted-foreground">{t.inquiryBody}</p>
                <form className="mt-6 grid gap-4">
                  <Field label={t.fields.name} />
                  <Field label={t.fields.email} type="email" />
                  <Field label={t.fields.company} />
                  <Field label={t.fields.budget} placeholder="$500-$1,000" />
                  <div className="grid gap-2">
                    <Label>{t.fields.message}</Label>
                    <Textarea
                      defaultValue={
                        selectedWork
                          ? locale === "zh"
                            ? `我想基于「${selectedWork.title}」这种风格询价。`
                            : `I would like a quote inspired by "${selectedWork.title}".`
                          : undefined
                      }
                    />
                  </div>
                  <Button>
                    <Mail className="h-4 w-4" /> {t.submit}
                  </Button>
                </form>
              </CardContent>
            </Card>
          </div>
        </section>

        <section className="mx-auto max-w-7xl px-4 pb-14 sm:px-6 lg:px-8">
          <h2 className="text-2xl font-semibold">{t.works}</h2>
          <div className="mt-6 grid gap-5 lg:grid-cols-3">
            {works.map((work) => (
              <Card key={work.id} className="overflow-hidden bg-white shadow-none">
                <div className="relative aspect-[4/3] bg-muted">
                  <Image src={work.thumbnail_url} alt={work.title} fill className="object-cover" />
                </div>
                <CardContent className="p-5">
                  <div className="flex items-start justify-between gap-3">
                    <div>
                      <p className="text-xs font-medium uppercase text-muted-foreground">{work.category}</p>
                      <h3 className="mt-2 text-xl font-semibold">{work.title}</h3>
                    </div>
                    <Badge variant="secondary">{work.format}</Badge>
                  </div>
                  <p className="mt-3 text-sm leading-6 text-muted-foreground">{work.description}</p>
                  <div className="mt-4 grid gap-2 text-sm">
                    <Meta icon={FileText} label={t.quote} value={t.customQuote} />
                    <Meta icon={Clock3} label={t.turnaround} value={work.turnaround} />
                  </div>
                  <Button asChild className="mt-5 w-full">
                    <Link href={withLocale(`/creators/${creator.id}?work=${work.id}#inquiry`, locale)}>
                      {t.inquiry}
                    </Link>
                  </Button>
                </CardContent>
              </Card>
            ))}
          </div>
        </section>
      </main>
    </PageShell>
  );
}

function Field({ label, ...props }: React.InputHTMLAttributes<HTMLInputElement> & { label: string }) {
  const id = label.toLowerCase().replaceAll(" ", "-");

  return (
    <div className="grid gap-2">
      <Label htmlFor={id}>{label}</Label>
      <Input id={id} {...props} />
    </div>
  );
}

function Meta({ icon: Icon, label, value }: { icon: typeof FileText; label: string; value: string }) {
  return (
    <div className="flex items-center justify-between gap-3 rounded-md border bg-muted/30 px-3 py-2">
      <span className="flex items-center gap-2 text-muted-foreground">
        <Icon className="h-4 w-4" />
        {label}
      </span>
      <span className="font-medium">{value}</span>
    </div>
  );
}
