"use server";

import { redirect } from "next/navigation";
import { createClient } from "@/lib/supabase/server";

type OAuthProvider = "google" | "github";

function hasSupabaseConfig() {
  return Boolean(process.env.NEXT_PUBLIC_SUPABASE_URL && process.env.NEXT_PUBLIC_SUPABASE_ANON_KEY);
}

export async function submitProjectAction(formData: FormData) {
  const companyName = String(formData.get("company_name") ?? "");
  const lang = String(formData.get("lang") ?? "en");

  if (!companyName.trim()) {
    redirect(`/start?error=missing-company&lang=${lang}`);
  }

  redirect(`/dashboard?submitted=1&lang=${lang}`);
}

export async function createCheckoutAction(formData: FormData) {
  const lang = String(formData.get("lang") ?? "en");
  redirect(`/start?lang=${lang}`);
}

export async function requestRevisionAction(formData: FormData) {
  const lang = String(formData.get("lang") ?? "en");
  redirect(`/dashboard?revision=requested&lang=${lang}`);
}

export async function updateOrderAction(formData: FormData) {
  const orderId = String(formData.get("order_id") ?? "");
  const lang = String(formData.get("lang") ?? "en");
  redirect(`/admin/orders/${orderId}?updated=1&lang=${lang}`);
}

export async function signInAction(formData: FormData) {
  const lang = String(formData.get("lang") ?? "en");

  if (!hasSupabaseConfig()) {
    redirect(`/login?error=auth-config&lang=${lang}`);
  }

  const email = String(formData.get("email") ?? "");
  const password = String(formData.get("password") ?? "");
  const supabase = await createClient();
  const { error } = await supabase.auth.signInWithPassword({ email, password });

  if (error) {
    redirect(`/login?error=${encodeURIComponent(error.message)}&lang=${lang}`);
  }

  redirect(`/dashboard?lang=${lang}`);
}

export async function signUpAction(formData: FormData) {
  const lang = String(formData.get("lang") ?? "en");

  if (!hasSupabaseConfig()) {
    redirect(`/login?error=auth-config&lang=${lang}`);
  }

  const email = String(formData.get("email") ?? "");
  const password = String(formData.get("password") ?? "");
  const supabase = await createClient();
  const { error } = await supabase.auth.signUp({
    email,
    password,
    options: {
      emailRedirectTo: `${process.env.NEXT_PUBLIC_APP_URL ?? "http://localhost:3000"}/auth/callback`
    }
  });

  if (error) {
    redirect(`/login?error=${encodeURIComponent(error.message)}&lang=${lang}`);
  }

  redirect(`/dashboard?signup=success&lang=${lang}`);
}

export async function oauthSignInAction(formData: FormData) {
  const lang = String(formData.get("lang") ?? "en");
  const provider = String(formData.get("provider") ?? "") as OAuthProvider;

  if (!hasSupabaseConfig()) {
    redirect(`/login?error=auth-config&lang=${lang}&site=global`);
  }

  if (!["google", "github"].includes(provider)) {
    redirect(`/login?error=unsupported-provider&lang=${lang}&site=global`);
  }

  const supabase = await createClient();
  const { data, error } = await supabase.auth.signInWithOAuth({
    provider,
    options: {
      redirectTo: `${process.env.NEXT_PUBLIC_APP_URL ?? "http://localhost:3000"}/auth/callback`
    }
  });

  if (error || !data.url) {
    redirect(`/login?error=${encodeURIComponent(error?.message ?? "OAuth unavailable")}&lang=${lang}&site=global`);
  }

  redirect(data.url);
}

export async function signOutAction(formData?: FormData) {
  const lang = String(formData?.get("lang") ?? "en");

  if (hasSupabaseConfig()) {
    const supabase = await createClient();
    await supabase.auth.signOut();
  }

  redirect(`/?lang=${lang}`);
}
