import Link from "next/link";
import { notFound } from "next/navigation";
import { Download, RotateCcw } from "lucide-react";
import { requestRevisionAction } from "@/app/actions";
import { PageShell } from "@/components/page-shell";
import { StatusBadge } from "@/components/status-badge";
import { Button } from "@/components/ui/button";
import { Card, CardContent } from "@/components/ui/card";
import { Textarea } from "@/components/ui/textarea";
import { deliverables, orders, projects } from "@/lib/data";
import { getLocale, type SearchParams, withLocale } from "@/lib/i18n";
import { formatCurrency, formatDate } from "@/lib/utils";

const copy = {
  en: {
    back: "Back to dashboard",
    projectBrief: "Project brief",
    labels: {
      plan: "Quote",
      amount: "Amount",
      product: "Product",
      category: "Category",
      platforms: "Platforms",
      format: "Format",
      videos: "Videos",
      deadline: "Deadline",
      brandStyle: "Brand style",
      campaignGoal: "Campaign goal",
      notes: "Notes"
    },
    deliverables: "Deliverables",
    version: "Version",
    download: "Download",
    preparing: "Your assigned studio is preparing review files.",
    revisionTitle: "Request revision",
    revisionPlaceholder: "Add clear, consolidated revision notes.",
    revisionButton: "Request revision"
  },
  zh: {
    back: "返回客户后台",
    projectBrief: "项目简报",
    labels: {
      plan: "报价",
      amount: "金额",
      product: "产品",
      category: "类别",
      platforms: "平台",
      format: "格式",
      videos: "视频数量",
      deadline: "截止日期",
      brandStyle: "品牌风格",
      campaignGoal: "广告目标",
      notes: "补充说明"
    },
    deliverables: "交付文件",
    version: "版本",
    download: "下载",
    preparing: "已分配的工作室正在准备审核文件。",
    revisionTitle: "申请修改",
    revisionPlaceholder: "请填写清晰、合并后的修改意见。",
    revisionButton: "申请修改"
  }
};

type OrderPageProps = {
  params: Promise<{ id: string }>;
  searchParams: Promise<SearchParams>;
};

export default async function ClientOrderPage({ params, searchParams }: OrderPageProps) {
  const { id } = await params;
  const locale = getLocale(await searchParams);
  const t = copy[locale];
  const order = orders.find((item) => item.id === id);

  if (!order) {
    notFound();
  }

  const project = projects.find((item) => item.id === order.project_id);
  const orderDeliverables = deliverables.filter((item) => item.order_id === order.id);

  return (
    <PageShell locale={locale}>
      <main className="mx-auto max-w-6xl px-4 py-10 sm:px-6 lg:px-8">
        <Link href={withLocale("/dashboard", locale)} className="text-sm text-muted-foreground hover:text-foreground">
          {t.back}
        </Link>
        <div className="mt-5 flex flex-col gap-4 sm:flex-row sm:items-end sm:justify-between">
          <div>
            <h1 className="text-4xl font-semibold tracking-tight">{order.id}</h1>
            <p className="mt-2 text-muted-foreground">
              {project?.company_name} · {formatDate(order.created_at)}
            </p>
          </div>
          <StatusBadge status={order.status} locale={locale} />
        </div>

        <div className="mt-8 grid gap-5 lg:grid-cols-[0.68fr_0.32fr]">
          <Card className="shadow-none">
            <CardContent className="p-6">
              <h2 className="text-lg font-semibold">{t.projectBrief}</h2>
              <div className="mt-5 grid gap-4 sm:grid-cols-2">
                {[
                  [t.labels.plan, order.plan_name],
                  [t.labels.amount, formatCurrency(order.amount)],
                  [t.labels.product, project?.product_url],
                  [t.labels.category, project?.category],
                  [t.labels.platforms, project?.target_platform],
                  [t.labels.format, project?.video_format],
                  [t.labels.videos, project?.video_count],
                  [t.labels.deadline, project ? formatDate(project.deadline) : ""],
                  [t.labels.brandStyle, project?.brand_style],
                  [t.labels.campaignGoal, project?.campaign_goal]
                ].map(([label, value]) => (
                  <div key={String(label)} className="rounded-lg border p-4">
                    <p className="text-xs uppercase tracking-[0.14em] text-muted-foreground">
                      {label}
                    </p>
                    <p className="mt-2 text-sm font-medium">{value}</p>
                  </div>
                ))}
              </div>
              <div className="mt-4 rounded-lg border p-4">
                <p className="text-xs uppercase tracking-[0.14em] text-muted-foreground">
                  {t.labels.notes}
                </p>
                <p className="mt-2 text-sm leading-6 text-muted-foreground">{project?.notes}</p>
              </div>
            </CardContent>
          </Card>

          <div className="space-y-5">
            <Card className="shadow-none">
              <CardContent className="p-6">
                <h2 className="text-lg font-semibold">{t.deliverables}</h2>
                <div className="mt-5 space-y-3">
                  {orderDeliverables.length ? (
                    orderDeliverables.map((deliverable) => (
                      <div key={deliverable.id} className="rounded-lg border p-4">
                        <div className="flex items-center justify-between gap-3">
                          <div>
                            <p className="font-medium">{t.version} {deliverable.version}</p>
                            <p className="mt-1 text-xs text-muted-foreground">
                              {formatDate(deliverable.created_at)}
                            </p>
                          </div>
                          <Button asChild size="sm" variant="outline">
                            <a href={deliverable.file_url}>
                              <Download className="h-4 w-4" /> {t.download}
                            </a>
                          </Button>
                        </div>
                        <p className="mt-3 text-sm text-muted-foreground">{deliverable.notes}</p>
                      </div>
                    ))
                  ) : (
                    <p className="text-sm text-muted-foreground">
                      {t.preparing}
                    </p>
                  )}
                </div>
              </CardContent>
            </Card>

            <Card className="shadow-none">
              <CardContent className="p-6">
                <h2 className="text-lg font-semibold">{t.revisionTitle}</h2>
                <form action={requestRevisionAction} className="mt-4 grid gap-3">
                  <input type="hidden" name="lang" value={locale} />
                  <Textarea name="revision_notes" placeholder={t.revisionPlaceholder} />
                  <Button variant="outline">
                    <RotateCcw className="h-4 w-4" /> {t.revisionButton}
                  </Button>
                </form>
              </CardContent>
            </Card>
          </div>
        </div>
      </main>
    </PageShell>
  );
}
