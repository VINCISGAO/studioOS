import Link from "next/link";
import { Download, ExternalLink, Plus } from "lucide-react";
import { PageShell } from "@/components/page-shell";
import { StatusBadge } from "@/components/status-badge";
import { Button } from "@/components/ui/button";
import { Card, CardContent } from "@/components/ui/card";
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table";
import { deliverables, orders, projects } from "@/lib/data";
import { getLocale, type SearchParams, withLocale } from "@/lib/i18n";
import { formatCurrency, formatDate } from "@/lib/utils";

const copy = {
  en: {
    eyebrow: "Client dashboard",
    title: "Your AI ad orders",
    newProject: "New project",
    activeOrders: "Active orders",
    totalSpend: "Total spend",
    latestDelivery: "Latest delivery",
    pending: "Pending",
    table: ["Order", "Project", "Quote", "Status", "Payment", "Amount"],
    unknown: "Unknown",
    deliverables: "Deliverables",
    version: "Version",
    download: "Download",
    noDeliverables: "Final files will appear here once an admin uploads deliverables.",
    accountAccess: "Account access",
    authNote:
      "Supabase Auth is scaffolded for sign up and sign in. Once environment keys are configured, this page should be protected and scoped to the signed-in client.",
    openSample: "Open sample order"
  },
  zh: {
    eyebrow: "客户后台",
    title: "你的 AI 广告订单",
    newProject: "新建项目",
    activeOrders: "进行中订单",
    totalSpend: "累计支出",
    latestDelivery: "最新交付",
    pending: "待交付",
    table: ["订单", "项目", "报价", "状态", "付款", "金额"],
    unknown: "未知",
    deliverables: "交付文件",
    version: "版本",
    download: "下载",
    noDeliverables: "管理员上传交付文件后，最终文件会显示在这里。",
    accountAccess: "账户访问",
    authNote:
      "Supabase Auth 已预留注册与登录能力。配置环境密钥后，此页面会按已登录客户进行访问保护和数据隔离。",
    openSample: "打开示例订单"
  }
};

type DashboardPageProps = {
  searchParams: Promise<SearchParams>;
};

export default async function DashboardPage({ searchParams }: DashboardPageProps) {
  const locale = getLocale(await searchParams);
  const t = copy[locale];
  const totalSpend = orders.reduce((sum, order) => sum + order.amount, 0);
  const activeOrders = orders.filter((order) => !["completed", "cancelled"].includes(order.status));
  const latestDeliverable = deliverables[0];

  return (
    <PageShell locale={locale}>
      <main className="mx-auto max-w-7xl px-4 py-10 sm:px-6 lg:px-8">
        <div className="flex flex-col gap-4 sm:flex-row sm:items-end sm:justify-between">
          <div>
            <p className="text-sm font-semibold uppercase tracking-[0.2em] text-muted-foreground">
              {t.eyebrow}
            </p>
            <h1 className="mt-3 text-4xl font-semibold tracking-tight">{t.title}</h1>
          </div>
          <Button asChild>
            <Link href={withLocale("/start", locale)}>
              <Plus className="h-4 w-4" /> {t.newProject}
            </Link>
          </Button>
        </div>

        <div className="mt-8 grid gap-4 md:grid-cols-3">
          {[
            [t.activeOrders, activeOrders.length],
            [t.totalSpend, formatCurrency(totalSpend)],
            [t.latestDelivery, latestDeliverable ? `v${latestDeliverable.version}` : t.pending]
          ].map(([label, value]) => (
            <Card key={label} className="shadow-none">
              <CardContent className="p-5">
                <p className="text-sm text-muted-foreground">{label}</p>
                <div className="mt-2 text-3xl font-semibold">{value}</div>
              </CardContent>
            </Card>
          ))}
        </div>

        <Card className="mt-8 shadow-none">
          <CardContent className="p-0">
            <Table>
              <TableHeader>
                <TableRow>
                  {t.table.map((heading) => (
                    <TableHead key={heading} className={heading === t.table[5] ? "text-right" : undefined}>
                      {heading}
                    </TableHead>
                  ))}
                </TableRow>
              </TableHeader>
              <TableBody>
                {orders.map((order) => {
                  const project = projects.find((item) => item.id === order.project_id);
                  return (
                    <TableRow key={order.id}>
                      <TableCell className="font-medium">
                        <Link href={withLocale(`/dashboard/orders/${order.id}`, locale)} className="hover:underline">
                          {order.id}
                        </Link>
                      </TableCell>
                      <TableCell>
                        <div>{project?.company_name}</div>
                        <div className="text-xs text-muted-foreground">
                          {project ? formatDate(project.created_at) : t.unknown}
                        </div>
                      </TableCell>
                      <TableCell>{order.plan_name}</TableCell>
                      <TableCell>
                        <StatusBadge status={order.status} locale={locale} />
                      </TableCell>
                      <TableCell className="capitalize">{order.payment_status}</TableCell>
                      <TableCell className="text-right">{formatCurrency(order.amount)}</TableCell>
                    </TableRow>
                  );
                })}
              </TableBody>
            </Table>
          </CardContent>
        </Card>

        <div className="mt-8 grid gap-4 lg:grid-cols-2">
          <Card className="shadow-none">
            <CardContent className="p-6">
              <h2 className="text-lg font-semibold">{t.deliverables}</h2>
              {latestDeliverable ? (
                <div className="mt-5 rounded-lg border bg-muted/30 p-4">
                  <div className="flex items-start justify-between gap-4">
                    <div>
                      <p className="font-medium">{t.version} {latestDeliverable.version}</p>
                      <p className="mt-1 text-sm text-muted-foreground">{latestDeliverable.notes}</p>
                    </div>
                    <Button asChild variant="outline" size="sm">
                      <a href={latestDeliverable.file_url}>
                        <Download className="h-4 w-4" /> {t.download}
                      </a>
                    </Button>
                  </div>
                </div>
              ) : (
                <p className="mt-4 text-sm text-muted-foreground">
                  {t.noDeliverables}
                </p>
              )}
            </CardContent>
          </Card>
          <Card className="shadow-none">
            <CardContent className="p-6">
              <h2 className="text-lg font-semibold">{t.accountAccess}</h2>
              <p className="mt-3 text-sm leading-6 text-muted-foreground">
                {t.authNote}
              </p>
              <Button asChild variant="outline" className="mt-5">
                <Link href={withLocale("/dashboard/orders/ord_7001", locale)}>
                  {t.openSample} <ExternalLink className="h-4 w-4" />
                </Link>
              </Button>
            </CardContent>
          </Card>
        </div>
      </main>
    </PageShell>
  );
}
