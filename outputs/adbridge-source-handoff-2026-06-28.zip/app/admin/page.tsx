import Link from "next/link";
import { DollarSign, FolderKanban, Scale, ShieldCheck, UsersRound, Video } from "lucide-react";
import { PageShell } from "@/components/page-shell";
import { StatusBadge } from "@/components/status-badge";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Card, CardContent } from "@/components/ui/card";
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table";
import { creators, deposits, disputes, orders, projects, refundRequests } from "@/lib/data";
import { getLocale, type SearchParams, withLocale } from "@/lib/i18n";
import { formatCurrency, formatDate } from "@/lib/utils";

const copy = {
  en: {
    eyebrow: "Admin dashboard",
    title: "Operations command center",
    metrics: {
      projects: "Projects",
      orders: "Orders",
      paidVolume: "Paid volume",
      unassigned: "Unassigned",
      deposits: "Deposits",
      disputes: "Disputes"
    },
    allOrders: "All orders",
    table: ["Order", "Client", "Status", "Creator", "Payment", "Amount"],
    unassigned: "Unassigned",
    submittedProjects: "Submitted projects",
    viewOrder: "View order",
    trustOps: "Trust operations",
    deposits: "Deposit management",
    disputes: "Refunds and disputes"
  },
  zh: {
    eyebrow: "管理后台",
    title: "运营控制中心",
    metrics: {
      projects: "项目",
      orders: "订单",
      paidVolume: "已付款金额",
      unassigned: "未分配",
      deposits: "保证金",
      disputes: "争议"
    },
    allOrders: "全部订单",
    table: ["订单", "客户", "状态", "创作者", "付款", "金额"],
    unassigned: "未分配",
    submittedProjects: "已提交项目",
    viewOrder: "查看订单",
    trustOps: "交易安全运营",
    deposits: "保证金管理",
    disputes: "退款与争议"
  }
};

type AdminPageProps = {
  searchParams: Promise<SearchParams>;
};

export default async function AdminPage({ searchParams }: AdminPageProps) {
  const locale = getLocale(await searchParams);
  const t = copy[locale];
  const revenue = orders.reduce((sum, order) => sum + order.amount, 0);
  const unassigned = orders.filter((order) => !order.assigned_creator_id).length;
  const depositTotal = deposits.reduce((sum, deposit) => sum + deposit.amount, 0);
  const metrics = [
    { icon: FolderKanban, label: t.metrics.projects, value: String(projects.length) },
    { icon: Video, label: t.metrics.orders, value: String(orders.length) },
    { icon: DollarSign, label: t.metrics.paidVolume, value: formatCurrency(revenue) },
    { icon: UsersRound, label: t.metrics.unassigned, value: String(unassigned) },
    { icon: ShieldCheck, label: t.metrics.deposits, value: formatCurrency(depositTotal) },
    { icon: Scale, label: t.metrics.disputes, value: String(disputes.length + refundRequests.length) }
  ];

  return (
    <PageShell locale={locale}>
      <main className="mx-auto max-w-7xl px-4 py-10 sm:px-6 lg:px-8">
        <div>
          <p className="text-sm font-semibold uppercase tracking-[0.2em] text-muted-foreground">
            {t.eyebrow}
          </p>
          <h1 className="mt-3 text-4xl font-semibold tracking-tight">{t.title}</h1>
        </div>

        <div className="mt-8 grid gap-4 md:grid-cols-3 xl:grid-cols-6">
          {metrics.map(({ icon: Icon, label, value }) => (
            <Card key={label} className="shadow-none">
              <CardContent className="p-5">
                <Icon className="h-5 w-5 text-muted-foreground" />
                <p className="mt-5 text-sm text-muted-foreground">{label}</p>
                <div className="mt-2 text-3xl font-semibold">{value}</div>
              </CardContent>
            </Card>
          ))}
        </div>

        <div className="mt-8 grid gap-6 lg:grid-cols-[1fr_0.34fr]">
          <Card className="shadow-none">
            <CardContent className="p-0">
              <div className="border-b p-6">
                <h2 className="text-lg font-semibold">{t.allOrders}</h2>
              </div>
              <Table>
                <TableHeader>
                  <TableRow>
                    {t.table.map((heading) => (
                      <TableHead key={heading} className={heading === t.table[5] ? "text-right" : undefined}>
                        {heading}
                      </TableHead>
                    ))}
                  </TableRow>
                </TableHeader>
                <TableBody>
                  {orders.map((order) => {
                    const project = projects.find((item) => item.id === order.project_id);
                    const creator = creators.find((item) => item.id === order.assigned_creator_id);
                    return (
                      <TableRow key={order.id}>
                        <TableCell className="font-medium">
                          <Link href={withLocale(`/admin/orders/${order.id}`, locale)} className="hover:underline">
                            {order.id}
                          </Link>
                        </TableCell>
                        <TableCell>
                          <div>{project?.company_name}</div>
                          <div className="text-xs text-muted-foreground">{project?.email}</div>
                        </TableCell>
                        <TableCell>
                          <StatusBadge status={order.status} locale={locale} />
                        </TableCell>
                        <TableCell>{creator?.name ?? t.unassigned}</TableCell>
                        <TableCell>
                          <Badge variant="success">{order.payment_status}</Badge>
                        </TableCell>
                        <TableCell className="text-right">{formatCurrency(order.amount)}</TableCell>
                      </TableRow>
                    );
                  })}
                </TableBody>
              </Table>
            </CardContent>
          </Card>

          <Card className="shadow-none">
            <CardContent className="p-6">
              <h2 className="text-lg font-semibold">{t.submittedProjects}</h2>
              <div className="mt-5 space-y-4">
                {projects.map((project) => (
                  <div key={project.id} className="rounded-lg border p-4">
                    <div className="flex items-center justify-between gap-3">
                      <div>
                        <p className="font-medium">{project.company_name}</p>
                        <p className="mt-1 text-xs text-muted-foreground">
                          {formatDate(project.created_at)}
                        </p>
                      </div>
                      <StatusBadge status={project.status} locale={locale} />
                    </div>
                    <p className="mt-3 text-sm text-muted-foreground">{project.campaign_goal}</p>
                    <Button asChild variant="outline" size="sm" className="mt-4">
                      <Link
                        href={withLocale(
                          `/admin/orders/${orders.find((order) => order.project_id === project.id)?.id}`,
                          locale
                        )}
                      >
                        {t.viewOrder}
                      </Link>
                    </Button>
                  </div>
                ))}
              </div>
            </CardContent>
          </Card>
        </div>

        <Card className="mt-8 shadow-none">
          <CardContent className="p-6">
            <div className="flex flex-col gap-4 sm:flex-row sm:items-center sm:justify-between">
              <div>
                <h2 className="text-lg font-semibold">{t.trustOps}</h2>
                <p className="mt-2 text-sm text-muted-foreground">
                  {locale === "zh"
                    ? "集中处理承接人保证金、退款申请和订单争议。"
                    : "Manage creator deposits, refund requests, and order disputes in one place."}
                </p>
              </div>
              <div className="flex flex-col gap-2 sm:flex-row">
                <Button asChild variant="outline">
                  <Link href={withLocale("/admin/deposits", locale)}>
                    <ShieldCheck className="h-4 w-4" /> {t.deposits}
                  </Link>
                </Button>
                <Button asChild variant="outline">
                  <Link href={withLocale("/admin/disputes", locale)}>
                    <Scale className="h-4 w-4" /> {t.disputes}
                  </Link>
                </Button>
              </div>
            </div>
          </CardContent>
        </Card>
      </main>
    </PageShell>
  );
}
