import Link from "next/link";
import { ArrowLeft, ShieldCheck } from "lucide-react";
import { PageShell } from "@/components/page-shell";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Card, CardContent } from "@/components/ui/card";
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table";
import { creators, deposits } from "@/lib/data";
import { getLocale, type SearchParams, withLocale } from "@/lib/i18n";
import { formatCurrency, formatDate } from "@/lib/utils";

const copy = {
  en: {
    back: "Back to admin",
    eyebrow: "Deposit operations",
    title: "Creator guarantee deposits",
    subtitle: "Review paid, frozen, deducted, and refund-requested deposits before creators accept or exit orders.",
    table: ["Creator", "Amount", "Status", "Refundable after", "Reason", "Action"],
    review: "Review"
  },
  zh: {
    back: "返回管理后台",
    eyebrow: "保证金管理",
    title: "承接人平台保证金",
    subtitle: "审核已缴纳、冻结、扣除和申请退还的保证金，确保承接人接单和退出都可控。",
    table: ["承接人", "金额", "状态", "可退还时间", "原因", "操作"],
    review: "审核"
  }
};

type AdminDepositsPageProps = {
  searchParams: Promise<SearchParams>;
};

export default async function AdminDepositsPage({ searchParams }: AdminDepositsPageProps) {
  const locale = getLocale(await searchParams);
  const t = copy[locale];
  const total = deposits.reduce((sum, deposit) => sum + deposit.amount, 0);
  const requested = deposits.filter((deposit) => deposit.status === "refund_requested").length;

  return (
    <PageShell locale={locale}>
      <main className="mx-auto max-w-7xl px-4 py-10 sm:px-6 lg:px-8">
        <Button asChild variant="outline" size="sm">
          <Link href={withLocale("/admin", locale)}>
            <ArrowLeft className="h-4 w-4" /> {t.back}
          </Link>
        </Button>
        <div className="mt-8">
          <p className="text-sm font-semibold uppercase tracking-[0.2em] text-muted-foreground">{t.eyebrow}</p>
          <h1 className="mt-3 text-4xl font-semibold tracking-tight">{t.title}</h1>
          <p className="mt-3 max-w-3xl text-sm leading-6 text-muted-foreground">{t.subtitle}</p>
        </div>
        <div className="mt-8 grid gap-4 md:grid-cols-3">
          <Metric label={locale === "zh" ? "保证金总额" : "Total deposits"} value={formatCurrency(total)} />
          <Metric label={locale === "zh" ? "退还申请" : "Refund requests"} value={String(requested)} />
          <Metric label={locale === "zh" ? "承接人数量" : "Creators"} value={String(creators.length)} />
        </div>
        <Card className="mt-8 shadow-none">
          <CardContent className="p-0">
            <Table>
              <TableHeader>
                <TableRow>
                  {t.table.map((heading) => (
                    <TableHead key={heading}>{heading}</TableHead>
                  ))}
                </TableRow>
              </TableHeader>
              <TableBody>
                {deposits.map((deposit) => {
                  const creator = creators.find((item) => item.id === deposit.creator_id);
                  return (
                    <TableRow key={deposit.id}>
                      <TableCell>
                        <div className="font-medium">{creator?.name}</div>
                        <div className="text-xs text-muted-foreground">{creator?.email}</div>
                      </TableCell>
                      <TableCell>{formatCurrency(deposit.amount)}</TableCell>
                      <TableCell>
                        <Badge variant={deposit.status === "paid" ? "success" : "warning"}>{deposit.status}</Badge>
                      </TableCell>
                      <TableCell>{deposit.refundable_after ? formatDate(deposit.refundable_after) : "-"}</TableCell>
                      <TableCell>{deposit.reason}</TableCell>
                      <TableCell>
                        <Button size="sm" variant="outline">
                          <ShieldCheck className="h-4 w-4" /> {t.review}
                        </Button>
                      </TableCell>
                    </TableRow>
                  );
                })}
              </TableBody>
            </Table>
          </CardContent>
        </Card>
      </main>
    </PageShell>
  );
}

function Metric({ label, value }: { label: string; value: string }) {
  return (
    <Card className="shadow-none">
      <CardContent className="p-5">
        <p className="text-sm text-muted-foreground">{label}</p>
        <div className="mt-2 text-3xl font-semibold">{value}</div>
      </CardContent>
    </Card>
  );
}
