import Link from "next/link";
import { ArrowRight, BadgeDollarSign, CalendarClock, ClipboardList, ShieldCheck } from "lucide-react";
import { PageShell } from "@/components/page-shell";
import { StatusBadge } from "@/components/status-badge";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Card, CardContent } from "@/components/ui/card";
import { projectApplications, projects } from "@/lib/data";
import { getLocale, type SearchParams, withLocale } from "@/lib/i18n";
import { formatDate } from "@/lib/utils";

const copy = {
  en: {
    eyebrow: "Project desk",
    title: "Curated advertising briefs for approved creative operators.",
    subtitle:
      "AdBridge keeps the marketplace quiet: brands submit briefs, creators apply with a production plan, and the platform manages escrow, deposits, quality, and delivery.",
    apply: "Apply to produce",
    details: "View creator desk",
    budget: "Budget",
    deadline: "Deadline",
    applications: "Applications",
    format: "Format",
    trust: ["No open bidding race", "Escrow-backed orders", "Creator deposit required"]
  },
  zh: {
    eyebrow: "项目大厅",
    title: "给通过审核的广告承接人看的精选项目。",
    subtitle:
      "AdBridge 不做混乱竞价。品牌提交需求，承接人提交制作方案，平台负责托管付款、保证金、质量控制和最终交付。",
    apply: "申请承接",
    details: "进入承接人中心",
    budget: "预算",
    deadline: "截止",
    applications: "申请数",
    format: "格式",
    trust: ["不做低价竞价", "订单资金平台托管", "承接人需缴纳保证金"]
  }
};

type ProjectsPageProps = {
  searchParams: Promise<SearchParams>;
};

export default async function ProjectsPage({ searchParams }: ProjectsPageProps) {
  const locale = getLocale(await searchParams);
  const t = copy[locale];
  const openProjects = projects.filter((project) => !["completed", "cancelled", "refunded"].includes(project.status));

  return (
    <PageShell locale={locale}>
      <main className="bg-[#f6f6f3]">
        <section className="border-b">
          <div className="mx-auto max-w-7xl px-4 py-16 sm:px-6 lg:px-8">
            <div className="grid gap-8 lg:grid-cols-[0.72fr_0.28fr] lg:items-end">
              <div>
                <div className="inline-flex items-center gap-2 rounded-md border bg-white px-3 py-1.5 text-sm text-muted-foreground shadow-sm">
                  <ClipboardList className="h-4 w-4 text-foreground" />
                  {t.eyebrow}
                </div>
                <h1 className="mt-6 max-w-4xl text-balance text-5xl font-semibold leading-tight sm:text-6xl">
                  {t.title}
                </h1>
                <p className="mt-6 max-w-3xl text-lg leading-8 text-muted-foreground">{t.subtitle}</p>
              </div>
              <Card className="bg-white shadow-luxe">
                <CardContent className="p-6">
                  <div className="flex h-10 w-10 items-center justify-center rounded-md bg-primary text-primary-foreground">
                    <ShieldCheck className="h-5 w-5" />
                  </div>
                  <div className="mt-5 grid gap-3">
                    {t.trust.map((item) => (
                      <div key={item} className="border-t pt-3 text-sm font-medium text-muted-foreground">
                        {item}
                      </div>
                    ))}
                  </div>
                </CardContent>
              </Card>
            </div>
          </div>
        </section>

        <section className="mx-auto max-w-7xl px-4 py-10 sm:px-6 lg:px-8">
          <div className="grid gap-5 lg:grid-cols-3">
            {openProjects.map((project) => {
              const applicationCount = projectApplications.filter((item) => item.project_id === project.id).length;

              return (
                <Card key={project.id} className="bg-white shadow-none">
                  <CardContent className="flex h-full flex-col p-6">
                    <div className="flex items-start justify-between gap-3">
                      <div>
                        <p className="text-sm font-medium text-muted-foreground">{project.category}</p>
                        <h2 className="mt-2 text-2xl font-semibold">{project.company_name}</h2>
                      </div>
                      <StatusBadge status={project.status} locale={locale} />
                    </div>
                    <p className="mt-4 line-clamp-3 text-sm leading-6 text-muted-foreground">
                      {project.campaign_goal}
                    </p>
                    <div className="mt-6 grid gap-3 text-sm">
                      <Meta icon={BadgeDollarSign} label={t.budget} value={project.budget_range} />
                      <Meta icon={CalendarClock} label={t.deadline} value={formatDate(project.deadline)} />
                      <Meta icon={ClipboardList} label={t.format} value={`${project.video_count} / ${project.video_format}`} />
                    </div>
                    <div className="mt-5 flex flex-wrap gap-2">
                      {project.target_platform.split(",").map((platform) => (
                        <Badge key={platform.trim()} variant="secondary">
                          {platform.trim()}
                        </Badge>
                      ))}
                      <Badge variant="outline">
                        {t.applications}: {applicationCount}
                      </Badge>
                    </div>
                    <div className="mt-auto pt-6">
                      <Button asChild className="w-full">
                        <Link href={withLocale("/creator", locale)}>
                          {t.apply} <ArrowRight className="h-4 w-4" />
                        </Link>
                      </Button>
                    </div>
                  </CardContent>
                </Card>
              );
            })}
          </div>
          <div className="mt-8 flex justify-center">
            <Button asChild variant="outline">
              <Link href={withLocale("/creator", locale)}>
                {t.details} <ArrowRight className="h-4 w-4" />
              </Link>
            </Button>
          </div>
        </section>
      </main>
    </PageShell>
  );
}

function Meta({ icon: Icon, label, value }: { icon: typeof BadgeDollarSign; label: string; value: string }) {
  return (
    <div className="flex items-center justify-between gap-4 rounded-md border bg-muted/30 px-3 py-2">
      <span className="flex items-center gap-2 text-muted-foreground">
        <Icon className="h-4 w-4" />
        {label}
      </span>
      <span className="font-medium">{value}</span>
    </div>
  );
}
