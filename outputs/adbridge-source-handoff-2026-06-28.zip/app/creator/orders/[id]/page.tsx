import Link from "next/link";
import { ArrowLeft, Banknote, ShieldCheck, UploadCloud } from "lucide-react";
import { PageShell } from "@/components/page-shell";
import { StatusBadge } from "@/components/status-badge";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Card, CardContent } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { creators, deposits, orders, projects } from "@/lib/data";
import { getLocale, type SearchParams, withLocale } from "@/lib/i18n";
import { formatCurrency, formatDate } from "@/lib/utils";

const copy = {
  en: {
    back: "Back to creator desk",
    title: "Creator order",
    escrow: "Escrow",
    payout: "Creator payout",
    deposit: "Deposit",
    brief: "Production brief",
    upload: "Upload deliverable",
    file: "Video file",
    thumbnail: "Thumbnail",
    notes: "Delivery notes",
    submit: "Submit for client review",
    notFound: "Order not found"
  },
  zh: {
    back: "返回承接人中心",
    title: "承接订单",
    escrow: "托管金额",
    payout: "承接人收入",
    deposit: "保证金",
    brief: "制作需求",
    upload: "上传交付文件",
    file: "视频文件",
    thumbnail: "缩略图",
    notes: "交付说明",
    submit: "提交给客户审核",
    notFound: "未找到订单"
  }
};

type CreatorOrderPageProps = {
  params: Promise<{ id: string }>;
  searchParams: Promise<SearchParams>;
};

export default async function CreatorOrderPage({ params, searchParams }: CreatorOrderPageProps) {
  const [{ id }, query] = await Promise.all([params, searchParams]);
  const locale = getLocale(query);
  const t = copy[locale];
  const order = orders.find((item) => item.id === id);
  const project = order ? projects.find((item) => item.id === order.project_id) : undefined;
  const creator = order ? creators.find((item) => item.id === order.assigned_creator_id) : undefined;
  const deposit = creator ? deposits.find((item) => item.creator_id === creator.id) : undefined;

  if (!order || !project) {
    return (
      <PageShell locale={locale}>
        <main className="mx-auto max-w-3xl px-4 py-16 text-center">
          <h1 className="text-3xl font-semibold">{t.notFound}</h1>
          <Button asChild className="mt-6">
            <Link href={withLocale("/creator", locale)}>{t.back}</Link>
          </Button>
        </main>
      </PageShell>
    );
  }

  return (
    <PageShell locale={locale}>
      <main className="mx-auto max-w-7xl px-4 py-10 sm:px-6 lg:px-8">
        <Button asChild variant="outline" size="sm">
          <Link href={withLocale("/creator", locale)}>
            <ArrowLeft className="h-4 w-4" /> {t.back}
          </Link>
        </Button>

        <div className="mt-8 flex flex-col gap-4 sm:flex-row sm:items-end sm:justify-between">
          <div>
            <p className="text-sm font-semibold uppercase tracking-[0.2em] text-muted-foreground">{t.title}</p>
            <h1 className="mt-3 text-4xl font-semibold tracking-tight">{project.company_name}</h1>
            <p className="mt-2 text-sm text-muted-foreground">{formatDate(order.created_at)}</p>
          </div>
          <StatusBadge status={order.status} locale={locale} />
        </div>

        <div className="mt-8 grid gap-4 md:grid-cols-3">
          <Metric icon={Banknote} label={t.escrow} value={formatCurrency(order.amount)} note={order.payment_status} />
          <Metric icon={Banknote} label={t.payout} value={formatCurrency(order.creator_payout ?? 0)} note="held until approval" />
          <Metric icon={ShieldCheck} label={t.deposit} value={formatCurrency(deposit?.amount ?? 0)} note={deposit?.status ?? "unpaid"} />
        </div>

        <div className="mt-8 grid gap-6 lg:grid-cols-[0.56fr_0.44fr]">
          <Card className="shadow-none">
            <CardContent className="p-6">
              <h2 className="text-lg font-semibold">{t.brief}</h2>
              <div className="mt-5 grid gap-4 text-sm">
                <Info label="Category" value={project.category} />
                <Info label="Platform" value={project.target_platform} />
                <Info label="Format" value={`${project.video_count} videos / ${project.video_format}`} />
                <Info label="Deadline" value={formatDate(project.deadline)} />
                <Info label="Brand style" value={project.brand_style} />
              </div>
              <div className="mt-6 rounded-lg border bg-muted/30 p-4">
                <p className="font-medium">{project.campaign_goal}</p>
                <p className="mt-2 text-sm leading-6 text-muted-foreground">{project.notes}</p>
              </div>
            </CardContent>
          </Card>

          <Card className="shadow-none">
            <CardContent className="p-6">
              <div className="flex items-center justify-between gap-4">
                <h2 className="text-lg font-semibold">{t.upload}</h2>
                <Badge variant="warning">
                  <UploadCloud className="mr-1 h-3.5 w-3.5" />
                  v2
                </Badge>
              </div>
              <form className="mt-6 grid gap-5">
                <div className="grid gap-2">
                  <Label>{t.file}</Label>
                  <Input type="file" />
                </div>
                <div className="grid gap-2">
                  <Label>{t.thumbnail}</Label>
                  <Input type="file" />
                </div>
                <div className="grid gap-2">
                  <Label>{t.notes}</Label>
                  <Textarea />
                </div>
                <Button>
                  <UploadCloud className="h-4 w-4" /> {t.submit}
                </Button>
              </form>
            </CardContent>
          </Card>
        </div>
      </main>
    </PageShell>
  );
}

function Metric({
  icon: Icon,
  label,
  value,
  note
}: {
  icon: typeof Banknote;
  label: string;
  value: string;
  note: string;
}) {
  return (
    <Card className="shadow-none">
      <CardContent className="p-5">
        <Icon className="h-5 w-5 text-muted-foreground" />
        <p className="mt-5 text-sm text-muted-foreground">{label}</p>
        <div className="mt-2 text-3xl font-semibold">{value}</div>
        <p className="mt-2 text-xs uppercase text-muted-foreground">{note}</p>
      </CardContent>
    </Card>
  );
}

function Info({ label, value }: { label: string; value: string }) {
  return (
    <div className="flex items-center justify-between gap-4 border-b pb-3">
      <span className="text-muted-foreground">{label}</span>
      <span className="text-right font-medium">{value}</span>
    </div>
  );
}
