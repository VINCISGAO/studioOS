import Link from "next/link";
import { ArrowRight, Banknote, FileCheck2, ImagePlus, Mail, ShieldCheck, UploadCloud, WalletCards } from "lucide-react";
import { PageShell } from "@/components/page-shell";
import { StatusBadge } from "@/components/status-badge";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Card, CardContent } from "@/components/ui/card";
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table";
import { creatorWorks, creators, deposits, inquiries, orders, payouts, projects } from "@/lib/data";
import { getLocale, type SearchParams, withLocale } from "@/lib/i18n";
import { formatCurrency } from "@/lib/utils";

const copy = {
  en: {
    eyebrow: "Creator desk",
    title: "Publish your work, receive quote requests, and manage escrow orders.",
    subtitle:
      "Creators win demand through portfolio quality first. AdBridge supports inquiries, deposits, escrow orders, delivery, and payouts behind the scenes.",
    onboarding: "Apply as creator",
    deposit: "Guarantee deposit",
    depositAction: "Pay / request refund",
    activeOrders: "Active orders",
    payoutHeld: "Payout held",
    inquiries: "Inquiries",
    portfolio: "Portfolio works",
    publishWork: "Publish work",
    table: ["Work", "Platform", "Quote", "Turnaround", "Action"],
    customQuote: "Custom quote",
    viewPublic: "Public page",
    inquiryTable: ["Client", "Work", "Budget", "Status", "Action"],
    reply: "Reply quote",
    orderTable: ["Order", "Project", "Status", "Escrow", "Payout"],
    upload: "Open order"
  },
  zh: {
    eyebrow: "承接人中心",
    title: "发布作品、接收询价，并管理托管订单。",
    subtitle:
      "承接人先靠作品质量获得需求。AdBridge 在背后支持询价、保证金、托管订单、交付和结算。",
    onboarding: "申请成为承接人",
    deposit: "保证金",
    depositAction: "缴纳 / 申请退还",
    activeOrders: "进行中订单",
    payoutHeld: "待结算收入",
    inquiries: "询价",
    portfolio: "作品管理",
    publishWork: "发布作品",
    table: ["作品", "平台", "报价", "交付周期", "操作"],
    customQuote: "按项目询价",
    viewPublic: "公开主页",
    inquiryTable: ["客户", "作品", "预算", "状态", "操作"],
    reply: "回复报价",
    orderTable: ["订单", "项目", "状态", "托管", "收入"],
    upload: "打开订单"
  }
};

type CreatorPageProps = {
  searchParams: Promise<SearchParams>;
};

export default async function CreatorPage({ searchParams }: CreatorPageProps) {
  const locale = getLocale(await searchParams);
  const t = copy[locale];
  const creator = creators[0];
  const creatorDeposit = deposits.find((item) => item.creator_id === creator.id);
  const creatorOrders = orders.filter((order) => order.assigned_creator_id === creator.id);
  const works = creatorWorks.filter((work) => work.creator_id === creator.id);
  const creatorInquiries = inquiries.filter((inquiry) => inquiry.creator_id === creator.id);
  const creatorPayouts = payouts.filter((item) => item.creator_id === creator.id);
  const payoutHeld = creatorPayouts.reduce((sum, item) => sum + item.amount, 0);

  return (
    <PageShell locale={locale}>
      <main className="mx-auto max-w-7xl px-4 py-10 sm:px-6 lg:px-8">
        <div className="flex flex-col gap-4 sm:flex-row sm:items-end sm:justify-between">
          <div>
            <p className="text-sm font-semibold uppercase tracking-[0.2em] text-muted-foreground">
              {t.eyebrow}
            </p>
            <h1 className="mt-3 max-w-4xl text-4xl font-semibold tracking-tight sm:text-5xl">{t.title}</h1>
            <p className="mt-4 max-w-3xl text-base leading-7 text-muted-foreground">{t.subtitle}</p>
          </div>
          <Button asChild>
            <Link href={withLocale("/creator/onboarding", locale)}>
              {t.onboarding} <ArrowRight className="h-4 w-4" />
            </Link>
          </Button>
        </div>

        <div className="mt-8 grid gap-4 md:grid-cols-4">
          <Metric icon={ShieldCheck} label={t.deposit} value={formatCurrency(creatorDeposit?.amount ?? 0)} note={creatorDeposit?.status ?? "unpaid"} />
          <Metric icon={FileCheck2} label={t.activeOrders} value={String(creatorOrders.length)} note={creator.status} />
          <Metric icon={Banknote} label={t.payoutHeld} value={formatCurrency(payoutHeld)} note="escrow" />
          <Metric icon={WalletCards} label={t.inquiries} value={String(creatorInquiries.length)} note="quote" />
        </div>

        <div className="mt-8 grid gap-6 lg:grid-cols-[1fr_0.36fr]">
          <Card className="shadow-none">
            <CardContent className="p-0">
              <div className="border-b p-6">
                <div className="flex items-center justify-between gap-4">
                  <h2 className="text-lg font-semibold">{t.portfolio}</h2>
                  <Button size="sm">
                    <ImagePlus className="h-4 w-4" /> {t.publishWork}
                  </Button>
                </div>
              </div>
              <Table>
                <TableHeader>
                  <TableRow>
                    {t.table.map((heading) => (
                      <TableHead key={heading}>{heading}</TableHead>
                    ))}
                  </TableRow>
                </TableHeader>
                <TableBody>
                  {works.map((work) => {
                    return (
                      <TableRow key={work.id}>
                        <TableCell>
                          <div className="font-medium">{work.title}</div>
                          <div className="text-xs text-muted-foreground">{work.category} / {work.format}</div>
                        </TableCell>
                        <TableCell>{work.platform}</TableCell>
                        <TableCell>{t.customQuote}</TableCell>
                        <TableCell>{work.turnaround}</TableCell>
                        <TableCell>
                          <Button asChild variant="outline" size="sm">
                            <Link href={withLocale(`/creators/${creator.id}?work=${work.id}`, locale)}>
                              {t.viewPublic}
                            </Link>
                          </Button>
                        </TableCell>
                      </TableRow>
                    );
                  })}
                </TableBody>
              </Table>
            </CardContent>
          </Card>

          <Card className="shadow-none">
            <CardContent className="p-6">
              <div className="flex items-center justify-between gap-4">
                <div>
                  <h2 className="text-lg font-semibold">{t.deposit}</h2>
                  <p className="mt-2 text-sm text-muted-foreground">{creator.name}</p>
                </div>
                <Badge variant={creatorDeposit?.status === "paid" ? "success" : "warning"}>
                  {creatorDeposit?.status}
                </Badge>
              </div>
              <div className="mt-6 rounded-lg border bg-muted/30 p-4">
                <div className="text-3xl font-semibold">{formatCurrency(creatorDeposit?.amount ?? 0)}</div>
                <p className="mt-2 text-sm leading-6 text-muted-foreground">{creatorDeposit?.reason}</p>
              </div>
              <Button asChild className="mt-5 w-full" variant="outline">
                <Link href={withLocale("/creator/onboarding", locale)}>
                  {t.depositAction}
                </Link>
              </Button>
            </CardContent>
          </Card>
        </div>

        <Card className="mt-8 shadow-none">
          <CardContent className="p-0">
            <div className="border-b p-6">
              <h2 className="text-lg font-semibold">{t.inquiries}</h2>
            </div>
            <Table>
              <TableHeader>
                <TableRow>
                  {t.inquiryTable.map((heading) => (
                    <TableHead key={heading}>{heading}</TableHead>
                  ))}
                </TableRow>
              </TableHeader>
              <TableBody>
                {creatorInquiries.map((inquiry) => {
                  const work = creatorWorks.find((item) => item.id === inquiry.work_id);
                  return (
                    <TableRow key={inquiry.id}>
                      <TableCell>
                        <div className="font-medium">{inquiry.company_name}</div>
                        <div className="text-xs text-muted-foreground">{inquiry.client_email}</div>
                      </TableCell>
                      <TableCell>{work?.title ?? "-"}</TableCell>
                      <TableCell>{inquiry.budget_range}</TableCell>
                      <TableCell>
                        <Badge variant={inquiry.status === "new" ? "warning" : "success"}>{inquiry.status}</Badge>
                      </TableCell>
                      <TableCell>
                        <Button size="sm" variant="outline">
                          <Mail className="h-4 w-4" /> {t.reply}
                        </Button>
                      </TableCell>
                    </TableRow>
                  );
                })}
              </TableBody>
            </Table>
          </CardContent>
        </Card>

        <Card className="mt-8 shadow-none">
          <CardContent className="p-0">
            <div className="border-b p-6">
              <h2 className="text-lg font-semibold">{t.activeOrders}</h2>
            </div>
            <Table>
              <TableHeader>
                <TableRow>
                  {t.orderTable.map((heading) => (
                    <TableHead key={heading}>{heading}</TableHead>
                  ))}
                </TableRow>
              </TableHeader>
              <TableBody>
                {creatorOrders.map((order) => {
                  const project = projects.find((item) => item.id === order.project_id);
                  return (
                    <TableRow key={order.id}>
                      <TableCell className="font-medium">{order.id}</TableCell>
                      <TableCell>{project?.company_name}</TableCell>
                      <TableCell>
                        <StatusBadge status={order.status} locale={locale} />
                      </TableCell>
                      <TableCell>{order.payment_status}</TableCell>
                      <TableCell>{formatCurrency(order.creator_payout ?? 0)}</TableCell>
                      <TableCell>
                        <Button asChild size="sm" variant="outline">
                          <Link href={withLocale(`/creator/orders/${order.id}`, locale)}>
                            <UploadCloud className="h-4 w-4" /> {t.upload}
                          </Link>
                        </Button>
                      </TableCell>
                    </TableRow>
                  );
                })}
              </TableBody>
            </Table>
          </CardContent>
        </Card>
      </main>
    </PageShell>
  );
}

function Metric({
  icon: Icon,
  label,
  value,
  note
}: {
  icon: typeof ShieldCheck;
  label: string;
  value: string;
  note: string;
}) {
  return (
    <Card className="shadow-none">
      <CardContent className="p-5">
        <Icon className="h-5 w-5 text-muted-foreground" />
        <p className="mt-5 text-sm text-muted-foreground">{label}</p>
        <div className="mt-2 text-3xl font-semibold">{value}</div>
        <p className="mt-2 text-xs uppercase text-muted-foreground">{note}</p>
      </CardContent>
    </Card>
  );
}
