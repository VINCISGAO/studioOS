import { BadgeCheck, CreditCard, FileText, ShieldCheck } from "lucide-react";
import { PageShell } from "@/components/page-shell";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Card, CardContent } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { getLocale, type SearchParams } from "@/lib/i18n";

const copy = {
  en: {
    eyebrow: "Creator onboarding",
    title: "Apply to become a vetted AdBridge production partner.",
    subtitle:
      "Creators submit identity, portfolio, specialty, tooling, pricing, and deposit readiness. Admin approval is required before production work starts.",
    submit: "Submit application",
    deposit: "Guarantee deposit",
    depositBody:
      "Approved creators pay a refundable platform deposit before accepting orders. Deposits can be frozen during disputes and refunded after all orders are settled.",
    fields: ["Studio / creator name", "Email", "Country", "Portfolio URL", "Specialties", "AI tools", "Base price", "Delivery speed"],
    placeholders: {
      specialties: "Beauty, DTC, SaaS, TikTok, YouTube...",
      tools: "Runway, Kling, Midjourney, After Effects...",
      note: "Tell AdBridge what kind of advertising work you are strongest at."
    },
    rules: ["No unfinished orders", "No active dispute", "Admin review required"]
  },
  zh: {
    eyebrow: "承接人入驻",
    title: "申请成为 AdBridge 严选广告制作承接方。",
    subtitle:
      "承接人需要提交身份、作品集、擅长品类、制作工具、报价和保证金准备情况。通过平台审核后才可开始接单。",
    submit: "提交入驻申请",
    deposit: "保证金",
    depositBody:
      "通过审核的承接人需要缴纳可退还的平台保证金后才能承接订单。发生争议时保证金可冻结，所有订单结清后可申请退还。",
    fields: ["工作室 / 承接人名称", "邮箱", "国家 / 地区", "作品集链接", "擅长方向", "AI 工具", "基础报价", "交付速度"],
    placeholders: {
      specialties: "美妆、DTC、SaaS、TikTok、YouTube...",
      tools: "Runway、Kling、Midjourney、After Effects...",
      note: "告诉 AdBridge 你最擅长哪类广告制作。"
    },
    rules: ["没有未完成订单", "没有进行中争议", "需要管理员审核"]
  }
};

type OnboardingPageProps = {
  searchParams: Promise<SearchParams>;
};

export default async function CreatorOnboardingPage({ searchParams }: OnboardingPageProps) {
  const locale = getLocale(await searchParams);
  const t = copy[locale];

  return (
    <PageShell locale={locale}>
      <main className="bg-[#f6f6f3]">
        <section className="mx-auto grid max-w-7xl gap-8 px-4 py-12 sm:px-6 lg:grid-cols-[0.68fr_0.32fr] lg:px-8">
          <div>
            <p className="text-sm font-semibold uppercase tracking-[0.2em] text-muted-foreground">{t.eyebrow}</p>
            <h1 className="mt-4 max-w-4xl text-4xl font-semibold tracking-tight sm:text-5xl">{t.title}</h1>
            <p className="mt-5 max-w-3xl text-base leading-7 text-muted-foreground">{t.subtitle}</p>
            <Card className="mt-8 bg-white shadow-none">
              <CardContent className="p-6 sm:p-8">
                <form className="grid gap-6">
                  <div className="grid gap-4 sm:grid-cols-2">
                    {t.fields.slice(0, 4).map((field, index) => (
                      <Field key={field} label={field} type={index === 1 ? "email" : index === 3 ? "url" : "text"} />
                    ))}
                    <Field label={t.fields[4]} placeholder={t.placeholders.specialties} />
                    <Field label={t.fields[5]} placeholder={t.placeholders.tools} />
                    <Field label={t.fields[6]} type="number" />
                    <Field label={t.fields[7]} />
                  </div>
                  <div className="grid gap-2">
                    <Label>{locale === "zh" ? "补充说明" : "Notes"}</Label>
                    <Textarea placeholder={t.placeholders.note} />
                  </div>
                  <div className="flex flex-col gap-3 border-t pt-6 sm:flex-row sm:items-center sm:justify-between">
                    <div className="flex items-center gap-2 text-sm text-muted-foreground">
                      <FileText className="h-4 w-4" />
                      {locale === "zh" ? "提交后进入管理员审核" : "Submission enters admin review"}
                    </div>
                    <Button size="lg">{t.submit}</Button>
                  </div>
                </form>
              </CardContent>
            </Card>
          </div>

          <aside className="lg:pt-28">
            <Card className="sticky top-24 bg-white shadow-luxe">
              <CardContent className="p-6">
                <div className="flex h-11 w-11 items-center justify-center rounded-md bg-primary text-primary-foreground">
                  <ShieldCheck className="h-5 w-5" />
                </div>
                <h2 className="mt-5 text-xl font-semibold">{t.deposit}</h2>
                <p className="mt-3 text-sm leading-6 text-muted-foreground">{t.depositBody}</p>
                <div className="mt-6 rounded-lg border bg-muted/30 p-4">
                  <div className="flex items-center justify-between gap-4">
                    <div className="text-3xl font-semibold">{locale === "zh" ? "审核后确认" : "Set after review"}</div>
                    <Badge variant="warning">
                      <CreditCard className="mr-1 h-3.5 w-3.5" />
                      Stripe
                    </Badge>
                  </div>
                </div>
                <div className="mt-5 grid gap-3">
                  {t.rules.map((rule) => (
                    <div key={rule} className="flex items-center gap-2 text-sm text-muted-foreground">
                      <BadgeCheck className="h-4 w-4 text-foreground" />
                      {rule}
                    </div>
                  ))}
                </div>
              </CardContent>
            </Card>
          </aside>
        </section>
      </main>
    </PageShell>
  );
}

function Field({ label, ...props }: React.InputHTMLAttributes<HTMLInputElement> & { label: string }) {
  const id = label.toLowerCase().replaceAll(" ", "-").replaceAll("/", "");

  return (
    <div className="grid gap-2">
      <Label htmlFor={id}>{label}</Label>
      <Input id={id} {...props} />
    </div>
  );
}
