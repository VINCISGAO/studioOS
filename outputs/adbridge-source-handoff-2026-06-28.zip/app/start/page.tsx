import { submitProjectAction } from "@/app/actions";
import { PageShell } from "@/components/page-shell";
import { Button } from "@/components/ui/button";
import { Card, CardContent } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue
} from "@/components/ui/select";
import { Textarea } from "@/components/ui/textarea";
import { getLocale, type Locale, type SearchParams } from "@/lib/i18n";

const platforms = ["TikTok", "Meta", "YouTube", "Instagram", "Amazon"];
const formats = ["9:16", "16:9", "1:1"];
const budgets = ["$299-$500", "$500-$1,000", "$1,000-$2,500", "$2,500+"];
const categories = [
  "Beauty",
  "Consumer packaged goods",
  "Consumer tech",
  "Fashion",
  "Food and beverage",
  "Home",
  "Travel accessories",
  "Other"
];

const copy = {
  en: {
    eyebrow: "Start project",
    title: "Tell us what you are launching. We will match the right AI creative studio.",
    fields: {
      company: "Company name",
      email: "Email",
      productUrl: "Website / product link",
      category: "Product category",
      platform: "Target platform",
      format: "Video format",
      count: "Number of videos",
      budget: "Budget range",
      deadline: "Deadline",
      style: "Brand style",
      referenceLinks: "Reference video links",
      assets: "Upload logo/product assets",
      campaignGoal: "Campaign goal",
      notes: "Notes"
    },
    placeholders: {
      style: "Luxury, playful, UGC, cinematic...",
      referenceLinks: "Paste TikTok, YouTube, Drive, or ad library links.",
      campaignGoal: "Conversion lift, launch awareness, landing page education...",
      notes: "Anything the creative team should know before production starts."
    },
    storageNote: "Supabase Storage integration is scaffolded for production uploads.",
    submit: "Submit project brief",
    select: "Select",
    nextTitle: "What happens next",
    steps: [
      ["Brief review", "AdBridge reviews your goals, assets, and platform needs."],
      ["Creator quote", "Creators or AdBridge respond with scope, timeline, usage rights, and price."],
      ["Escrow payment", "After you accept a quote, payment moves into platform escrow."],
      ["Delivery", "Review cuts and final files appear in your dashboard."]
    ]
  },
  zh: {
    eyebrow: "开始项目",
    title: "告诉我们你要推广什么产品。我们会匹配最合适的 AI 创意工作室。",
    fields: {
      company: "公司名称",
      email: "邮箱",
      productUrl: "官网 / 产品链接",
      category: "产品类别",
      platform: "目标平台",
      format: "视频格式",
      count: "视频数量",
      budget: "预算范围",
      deadline: "截止日期",
      style: "品牌风格",
      referenceLinks: "参考视频链接",
      assets: "上传 Logo / 产品素材",
      campaignGoal: "广告目标",
      notes: "补充说明"
    },
    placeholders: {
      style: "高级、活泼、UGC、电影感...",
      referenceLinks: "粘贴 TikTok、YouTube、网盘或广告库链接。",
      campaignGoal: "提升转化、发布新品、落地页教育...",
      notes: "创意团队在制作前需要了解的任何信息。"
    },
    storageNote: "Supabase Storage 已预留为生产环境素材上传使用。",
    submit: "提交项目简报",
    select: "请选择",
    nextTitle: "接下来会发生什么",
    steps: [
      ["简报审核", "AdBridge 会审核你的目标、素材和平台需求。"],
      ["创作者报价", "创作者或 AdBridge 会回复范围、周期、使用权和价格。"],
      ["托管付款", "你接受报价后，项目款进入平台托管。"],
      ["交付文件", "审核视频和最终文件会出现在你的客户后台。"]
    ]
  }
};

type StartPageProps = {
  searchParams: Promise<SearchParams>;
};

export default async function StartPage({ searchParams }: StartPageProps) {
  const params = await searchParams;
  const locale = getLocale(params);
  const t = copy[locale];

  return (
    <PageShell locale={locale}>
      <main className="mx-auto grid max-w-7xl gap-8 px-4 py-12 sm:px-6 lg:grid-cols-[0.72fr_0.28fr] lg:px-8">
        <section>
          <p className="text-sm font-semibold uppercase tracking-[0.2em] text-muted-foreground">
            {t.eyebrow}
          </p>
          <h1 className="mt-4 max-w-3xl text-4xl font-semibold tracking-tight sm:text-5xl">
            {t.title}
          </h1>
          <Card className="mt-8 shadow-none">
            <CardContent className="p-6 sm:p-8">
              <form action={submitProjectAction} className="grid gap-6">
                <div className="grid gap-4 sm:grid-cols-2">
                  <Field label={t.fields.company} name="company_name" required />
                  <Field label={t.fields.email} name="email" type="email" required />
                  <Field label={t.fields.productUrl} name="product_url" type="url" />
                  <SelectField label={t.fields.category} name="category" options={categories} locale={locale} />
                  <SelectField label={t.fields.platform} name="target_platform" options={platforms} locale={locale} />
                  <SelectField label={t.fields.format} name="video_format" options={formats} locale={locale} />
                  <Field label={t.fields.count} name="video_count" type="number" min="1" />
                  <SelectField label={t.fields.budget} name="budget_range" options={budgets} locale={locale} />
                  <Field label={t.fields.deadline} name="deadline" type="date" />
                  <Field label={t.fields.style} name="brand_style" placeholder={t.placeholders.style} />
                </div>
                <div className="grid gap-4 sm:grid-cols-2">
                  <TextAreaField
                    label={t.fields.referenceLinks}
                    name="reference_links"
                    placeholder={t.placeholders.referenceLinks}
                  />
                  <div className="grid gap-2">
                    <Label htmlFor="assets">{t.fields.assets}</Label>
                    <Input id="assets" name="assets" type="file" multiple />
                    <p className="text-xs text-muted-foreground">
                      {t.storageNote}
                    </p>
                  </div>
                </div>
                <TextAreaField
                  label={t.fields.campaignGoal}
                  name="campaign_goal"
                  placeholder={t.placeholders.campaignGoal}
                  required
                />
                <TextAreaField
                  label={t.fields.notes}
                  name="notes"
                  placeholder={t.placeholders.notes}
                />
                <input type="hidden" name="lang" value={locale} />
                <div className="flex flex-col gap-3 border-t pt-6 sm:flex-row sm:items-center sm:justify-end">
                  <Button size="lg">{t.submit}</Button>
                </div>
              </form>
            </CardContent>
          </Card>
        </section>
        <aside className="lg:pt-28">
          <Card className="sticky top-24 shadow-luxe">
            <CardContent className="p-6">
              <h2 className="text-lg font-semibold">{t.nextTitle}</h2>
              <div className="mt-6 space-y-5">
                {t.steps.map(([title, body], index) => (
                  <div key={title} className="flex gap-3">
                    <div className="flex h-7 w-7 shrink-0 items-center justify-center rounded-md bg-primary text-xs font-medium text-primary-foreground">
                      {index + 1}
                    </div>
                    <div>
                      <div className="font-medium">{title}</div>
                      <p className="mt-1 text-sm leading-6 text-muted-foreground">{body}</p>
                    </div>
                  </div>
                ))}
              </div>
            </CardContent>
          </Card>
        </aside>
      </main>
    </PageShell>
  );
}

function Field({
  label,
  name,
  type = "text",
  ...props
}: React.InputHTMLAttributes<HTMLInputElement> & { label: string; name: string }) {
  return (
    <div className="grid gap-2">
      <Label htmlFor={name}>{label}</Label>
      <Input id={name} name={name} type={type} {...props} />
    </div>
  );
}

function TextAreaField({
  label,
  name,
  ...props
}: React.TextareaHTMLAttributes<HTMLTextAreaElement> & { label: string; name: string }) {
  return (
    <div className="grid gap-2">
      <Label htmlFor={name}>{label}</Label>
      <Textarea id={name} name={name} {...props} />
    </div>
  );
}

function SelectField({
  label,
  name,
  options,
  locale
}: {
  label: string;
  name: string;
  options: string[];
  locale: Locale;
}) {
  return (
    <div className="grid gap-2">
      <Label>{label}</Label>
      <Select name={name}>
        <SelectTrigger>
          <SelectValue placeholder={`${copy[locale].select} ${label}`} />
        </SelectTrigger>
        <SelectContent>
          {options.map((option) => (
            <SelectItem key={option} value={option}>
              {option}
            </SelectItem>
          ))}
        </SelectContent>
      </Select>
    </div>
  );
}
