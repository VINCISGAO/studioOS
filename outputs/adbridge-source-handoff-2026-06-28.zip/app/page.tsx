import Image from "next/image";
import Link from "next/link";
import {
  ArrowRight,
  BadgeCheck,
  CircleDollarSign,
  Clapperboard,
  Clock3,
  FileUp,
  Globe2,
  Layers3,
  Play,
  ShieldCheck,
  Sparkles,
  WandSparkles
} from "lucide-react";
import { PageShell } from "@/components/page-shell";
import { Button } from "@/components/ui/button";
import { Card, CardContent } from "@/components/ui/card";
import { getLocale, type SearchParams, withLocale } from "@/lib/i18n";

const copy = {
  en: {
    eyebrow: "Escrow-backed AI ad production marketplace",
    headline: "Find AI ad creators by their work, then transact safely.",
    subheadline:
      "AI creators publish portfolio work. Brands browse style and category fit, request quotes, then AdBridge manages escrow, deposits, delivery, and disputes.",
    primaryCta: "Start a Project",
    secondaryCta: "Browse Creators",
    trust: ["Brand and creator roles", "Escrow-backed orders", "Creator guarantee deposits", "Admin dispute review"],
    metrics: [
      { value: "2-sided", label: "brand and creator workflow" },
      { value: "Deposit", label: "creator accountability" },
      { value: "1:1", label: "admin-managed disputes" }
    ],
    heroPanel: {
      label: "Campaign package",
      title: "Premium product launch",
      status: "Studio matched",
      items: ["TikTok 9:16", "Meta feed", "YouTube cutdown"]
    },
    brandsEyebrow: "Positioned for international brands",
    brandsTitle: "A lighter marketplace: portfolio first, quote second, escrow after fit is clear.",
    brandBody:
      "Creators do not wait for platform dispatch. They register, publish work, and receive quote requests from brands that already understand their style. AdBridge steps in when the quote becomes a protected order.",
    principles: [
      {
        icon: ShieldCheck,
        title: "Curated supply",
        body: "Studios are vetted by portfolio, tools, turnaround speed, and category fit before client assignment."
      },
      {
        icon: Clock3,
        title: "Launch rhythm",
        body: "Quote requests carry scope, timing, assets, and revision needs before an escrow order is created."
      },
      {
        icon: Globe2,
        title: "Global execution",
        body: "Access specialized AI teams across regions while keeping one simple US-brand operating flow."
      }
    ],
    processEyebrow: "How it works",
    processTitle: "A cleaner flow that does not overload platform operations.",
    process: [
      {
        icon: FileUp,
        title: "Creators publish work",
        body: "Approved AI creators upload portfolio pieces with category, platform, price range, turnaround, and production style."
      },
      {
        icon: CircleDollarSign,
        title: "Escrow the project funds",
        body: "AdBridge creates the order, collects payment, and holds funds until the client review flow is complete."
      },
      {
        icon: WandSparkles,
        title: "Brands request quotes",
        body: "Advertisers browse real work, select the most relevant creator, and send a focused inquiry before payment."
      },
      {
        icon: Clapperboard,
        title: "Review and download",
        body: "Review cuts, request revisions, and download final deliverables from the client dashboard."
      }
    ],
    finalCtaTitle: "Launch AI ads through a cleaner transaction layer.",
    finalCtaBody: "Built for brands and vetted creators that need escrow, deposits, quality control, and a calm operating flow.",
    finalCtaButton: "Start the brief"
  },
  zh: {
    eyebrow: "带托管交易保障的 AI 广告制作平台",
    headline: "先看 AI 创作者作品，再安全成交。",
    subheadline:
      "AI 创作者注册并发布作品。广告需求方按风格、品类和价格筛选后发起询价，AdBridge 再负责托管付款、保证金、交付和争议处理。",
    primaryCta: "开始项目",
    secondaryCta: "浏览作品",
    trust: ["品牌方与承接人双角色", "订单资金平台托管", "承接人保证金", "管理员处理争议"],
    metrics: [
      { value: "双边", label: "品牌方与承接人流程" },
      { value: "保证金", label: "承接人履约约束" },
      { value: "1:1", label: "平台介入争议处理" }
    ],
    heroPanel: {
      label: "广告活动询价",
      title: "高端新品发布",
      status: "已匹配工作室",
      items: ["TikTok 9:16", "Meta 信息流", "YouTube 精简版"]
    },
    brandsEyebrow: "为国际品牌定位",
    brandsTitle: "更轻的平台逻辑：先展示作品，再询价，确认后进入担保交易。",
    brandBody:
      "承接人不需要等平台派单，而是先注册账号、发布作品并展示能力。品牌方看到合适风格后发起询价，报价确认后再进入托管订单，平台只在交易、保证金和争议环节介入。",
    principles: [
      {
        icon: ShieldCheck,
        title: "严选供给",
        body: "工作室会按照作品集、工具能力、交付速度和品类匹配度进行筛选。"
      },
      {
        icon: Clock3,
        title: "投放节奏",
        body: "询价会先明确范围、周期、素材和修改需求，再进入托管订单。"
      },
      {
        icon: Globe2,
        title: "全球执行",
        body: "通过统一的美国品牌流程，调用不同地区的专业 AI 创意团队。"
      }
    ],
    processEyebrow: "工作方式",
    processTitle: "不把平台累垮的轻量撮合流程。",
    process: [
      {
        icon: FileUp,
        title: "创作者发布作品",
        body: "通过审核的 AI 创作者上传作品，标注品类、平台、交付周期和制作风格。"
      },
      {
        icon: CircleDollarSign,
        title: "项目资金进入托管",
        body: "AdBridge 创建订单并收取项目款，资金在客户审核完成前保持托管状态。"
      },
      {
        icon: WandSparkles,
        title: "品牌方发起询价",
        body: "广告需求方浏览真实作品，选择合适创作者，并在付款前发送明确询价。"
      },
      {
        icon: Clapperboard,
        title: "审核并下载",
        body: "在客户后台审核视频、申请修改并下载最终交付文件。"
      }
    ],
    finalCtaTitle: "用更可控的交易流程启动 AI 广告制作。",
    finalCtaBody: "为需要托管付款、保证金、质量控制和全球创意供给的品牌与承接人打造。",
    finalCtaButton: "填写简报"
  }
};

type HomePageProps = {
  searchParams: Promise<SearchParams>;
};

export default async function HomePage({ searchParams }: HomePageProps) {
  const locale = getLocale(await searchParams);
  const t = copy[locale];

  return (
    <PageShell locale={locale}>
      <main className="overflow-hidden">
        <section className="relative border-b bg-[#f6f6f3]">
          <div className="absolute inset-0 luxury-grid opacity-70" />
          <div className="absolute inset-x-0 top-0 h-40 bg-gradient-to-b from-white to-transparent" />
          <div className="relative mx-auto grid min-h-[calc(100vh-4rem)] max-w-7xl items-center gap-12 px-4 py-16 sm:px-6 lg:grid-cols-[0.98fr_1.02fr] lg:px-8">
            <div className="max-w-3xl">
              <div className="inline-flex items-center gap-2 rounded-md border bg-white/75 px-3 py-1.5 text-sm text-muted-foreground shadow-sm backdrop-blur">
                <Sparkles className="h-4 w-4 text-foreground" />
                {t.eyebrow}
              </div>
              <h1 className="mt-7 text-balance text-5xl font-semibold leading-[1.02] text-foreground sm:text-6xl lg:text-7xl">
                {t.headline}
              </h1>
              <p className="mt-6 max-w-2xl text-balance text-lg leading-8 text-muted-foreground sm:text-xl">
                {t.subheadline}
              </p>
              <div className="mt-9 flex flex-col gap-3 sm:flex-row">
                <Button asChild size="lg" className="h-12 px-6">
                  <Link href={withLocale("/start", locale)}>
                    {t.primaryCta} <ArrowRight className="h-4 w-4" />
                  </Link>
                </Button>
                <Button asChild size="lg" variant="outline" className="h-12 bg-white/80 px-6">
                  <Link href={withLocale("/creators", locale)}>
                    <Play className="h-4 w-4" /> {t.secondaryCta}
                  </Link>
                </Button>
              </div>

              <div className="mt-9 flex flex-wrap gap-2">
                {t.trust.map((item) => (
                  <span
                    key={item}
                    className="inline-flex items-center gap-2 rounded-md border bg-white/70 px-3 py-2 text-xs font-medium text-muted-foreground shadow-sm backdrop-blur"
                  >
                    <BadgeCheck className="h-3.5 w-3.5 text-foreground" />
                    {item}
                  </span>
                ))}
              </div>
            </div>

            <div className="relative">
              <div className="absolute -inset-6 rounded-[2rem] bg-black/5 blur-3xl" />
              <div className="relative overflow-hidden rounded-lg border bg-black shadow-luxe">
                <div className="relative aspect-[4/4.35]">
                  <Image
                    src="https://images.unsplash.com/photo-1497366811353-6870744d04b2?q=80&w=1600&auto=format&fit=crop"
                    alt="International creative production studio"
                    fill
                    priority
                    className="object-cover opacity-80"
                  />
                  <div className="absolute inset-0 bg-gradient-to-t from-black via-black/20 to-transparent" />
                  <div className="absolute left-5 right-5 top-5 flex items-center justify-between text-white">
                    <div className="rounded-md border border-white/15 bg-white/10 px-3 py-1.5 text-xs backdrop-blur">
                      AdBridge Ops
                    </div>
                    <div className="rounded-md border border-white/15 bg-white/10 px-3 py-1.5 text-xs backdrop-blur">
                      72h SLA
                    </div>
                  </div>
                  <div className="absolute bottom-5 left-5 right-5">
                    <div className="glass-panel rounded-lg border border-white/30 p-5 shadow-2xl">
                      <div className="flex items-start justify-between gap-4">
                        <div>
                          <p className="text-xs font-medium uppercase text-muted-foreground">
                            {t.heroPanel.label}
                          </p>
                          <h2 className="mt-2 text-2xl font-semibold text-foreground">
                            {t.heroPanel.title}
                          </h2>
                        </div>
                        <span className="rounded-md bg-emerald-50 px-2.5 py-1 text-xs font-medium text-emerald-700">
                          {t.heroPanel.status}
                        </span>
                      </div>
                      <div className="mt-5 grid grid-cols-3 gap-2">
                        {t.heroPanel.items.map((item) => (
                          <div key={item} className="rounded-md border bg-white/80 p-3 text-xs font-medium">
                            {item}
                          </div>
                        ))}
                      </div>
                    </div>
                  </div>
                </div>
              </div>
              <div className="mt-5 grid grid-cols-3 gap-3">
                {t.metrics.map((item) => (
                  <div key={item.label} className="rounded-lg border bg-white/80 p-4 shadow-sm backdrop-blur">
                    <div className="text-2xl font-semibold">{item.value}</div>
                    <div className="mt-1 text-xs leading-5 text-muted-foreground">{item.label}</div>
                  </div>
                ))}
              </div>
            </div>
          </div>
        </section>

        <section className="mx-auto max-w-7xl px-4 py-24 sm:px-6 lg:px-8">
          <div className="grid gap-12 lg:grid-cols-[0.9fr_1.1fr] lg:items-end">
            <div>
              <p className="text-sm font-semibold uppercase tracking-[0.18em] text-muted-foreground">
                {t.brandsEyebrow}
              </p>
              <h2 className="mt-4 max-w-2xl text-balance text-4xl font-semibold leading-tight sm:text-5xl">
                {t.brandsTitle}
              </h2>
            </div>
            <p className="max-w-2xl text-lg leading-8 text-muted-foreground">{t.brandBody}</p>
          </div>

          <div className="mt-12 grid gap-4 lg:grid-cols-3">
            {t.principles.map(({ icon: Icon, title, body }) => (
              <Card key={title} className="border-muted bg-[#fbfbfa] shadow-none">
                <CardContent className="p-6">
                  <div className="flex h-10 w-10 items-center justify-center rounded-md bg-primary text-primary-foreground">
                    <Icon className="h-5 w-5" />
                  </div>
                  <h3 className="mt-7 text-xl font-semibold">{title}</h3>
                  <p className="mt-3 text-sm leading-6 text-muted-foreground">{body}</p>
                </CardContent>
              </Card>
            ))}
          </div>
        </section>

        <section className="border-y bg-black text-white">
          <div className="mx-auto grid max-w-7xl gap-12 px-4 py-24 sm:px-6 lg:grid-cols-[0.8fr_1.2fr] lg:px-8">
            <div>
              <p className="text-sm font-semibold uppercase tracking-[0.18em] text-white/55">
                {t.processEyebrow}
              </p>
              <h2 className="mt-4 text-balance text-4xl font-semibold leading-tight sm:text-5xl">
                {t.processTitle}
              </h2>
            </div>
            <div className="grid gap-3 sm:grid-cols-2">
              {t.process.map(({ icon: Icon, title, body }, index) => (
                <div key={title} className="rounded-lg border border-white/10 bg-white/[0.04] p-5">
                  <div className="flex items-center justify-between">
                    <Icon className="h-5 w-5 text-white" />
                    <span className="text-sm text-white/35">0{index + 1}</span>
                  </div>
                  <h3 className="mt-8 text-lg font-semibold">{title}</h3>
                  <p className="mt-3 text-sm leading-6 text-white/60">{body}</p>
                </div>
              ))}
            </div>
          </div>
        </section>

        <section className="mx-auto max-w-7xl px-4 py-20 sm:px-6 lg:px-8">
          <div className="relative overflow-hidden rounded-lg border bg-black p-8 text-white sm:p-12">
            <Image
              src="https://images.unsplash.com/photo-1557804506-669a67965ba0?q=80&w=1800&auto=format&fit=crop"
              alt="Brand team planning commercial launch"
              fill
              className="object-cover opacity-20"
            />
            <div className="relative flex flex-col gap-8 lg:flex-row lg:items-center lg:justify-between">
              <div>
                <div className="inline-flex items-center gap-2 rounded-md border border-white/15 bg-white/10 px-3 py-1.5 text-sm text-white/75">
                  <Layers3 className="h-4 w-4" />
                  AdBridge
                </div>
                <h2 className="mt-5 max-w-3xl text-balance text-4xl font-semibold leading-tight sm:text-5xl">
                  {t.finalCtaTitle}
                </h2>
                <p className="mt-4 max-w-2xl text-lg leading-8 text-white/65">{t.finalCtaBody}</p>
              </div>
              <Button asChild size="lg" variant="secondary" className="h-12 shrink-0 px-6">
                <Link href={withLocale("/start", locale)}>
                  {t.finalCtaButton} <ArrowRight className="h-4 w-4" />
                </Link>
              </Button>
            </div>
          </div>
        </section>
      </main>
    </PageShell>
  );
}
