import type { Metadata } from "next";
import "./globals.css";

export const metadata: Metadata = {
  title: "AdBridge | AI Commercial Videos for US Brands",
  description:
    "Order ready-to-run AI commercial videos from vetted global AI creative studios."
};

export default function RootLayout({
  children
}: Readonly<{
  children: React.ReactNode;
}>) {
  return (
    <html lang="en">
      <body>{children}</body>
    </html>
  );
}
